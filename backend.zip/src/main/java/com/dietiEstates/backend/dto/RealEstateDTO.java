package com.dietiEstates.backend.dto;

import java.sql.Timestamp;

import lombok.Data;

@Data
public abstract class RealEstateDTO {
    private Long id;
    private String description;
    private double size ;
    private int roomsNumber ;
    private int floorNumber;
    private String energyClass;
    private int parkingSpacesNumber ;
    private Timestamp uploadingDate;
    private String address;
    private String RealEstateAgent;
}