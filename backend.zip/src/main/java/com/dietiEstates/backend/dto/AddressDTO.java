
package com.dietiEstates.backend.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;


@Data
@NoArgsConstructor
@RequiredArgsConstructor
public class AddressDTO 
{
     @NonNull
     public String region;

     @NonNull
     private String province;

     @NonNull
     private String city;

     @NonNull
     private String cap;

     @NonNull
     private String street;

     @NonNull
     private Integer houseNumber;
}