package com.dietiEstates.backend.dto;

import java.time.LocalDateTime;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class RealEstateForSaleDTO extends RealEstateDTO {
    private double sellingPrice;
    private LocalDateTime availabilityDate;
    private String RealEstateState;
}