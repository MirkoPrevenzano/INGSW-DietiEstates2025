package com.dietiEstates.backend.dto;

import lombok.Data;

@Data
public class UserDTO {
    private String name;
    private String surname;
    private String username;
    private String password;
}
