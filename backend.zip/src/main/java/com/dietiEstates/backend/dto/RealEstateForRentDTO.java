package com.dietiEstates.backend.dto;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class RealEstateForRentDTO extends RealEstateDTO {
    private double rentalPrice;
    private double securityDeposit;
    private int contractYears;
    private double condoFee;
}