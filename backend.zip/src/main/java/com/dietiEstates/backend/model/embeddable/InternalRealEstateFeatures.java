
package com.dietiEstates.backend.model.embeddable;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Embeddable
@Setter
@EqualsAndHashCode
@NoArgsConstructor
@RequiredArgsConstructor
@ToString
public class InternalRealEstateFeatures 
{
    @NonNull
    @Column(name = "size", 
            nullable = false, 
            updatable = true)
    private Double size;

    @NonNull
    @Column(name = "rooms_number", 
            nullable = false, 
            updatable = true)
    private Integer roomsNumber;

    @NonNull
    @Column(name = "house_state", 
            nullable = false, 
            updatable = true,
            length = 25)
    private String houseState;

    @NonNull
    @Column(name = "furniture_state", 
            nullable = false, 
            updatable = true,
            length = 25)
    private String furnitureState;

    @Column(name = "has_air_conditioning",
            nullable = true, 
            updatable = true,
            columnDefinition = "boolean default false")     
    private boolean airConditioning;

    @Column(name = "has_heating",
            nullable = true, 
            updatable = true,
            columnDefinition = "boolean default false")  
    private boolean heating;



    public Double getSize() 
    {
        return size;
    }

    public Integer getRoomsNumber() 
    {
        return roomsNumber;
    }

    public String getHouseState() {
        return houseState;
    }

    public String getFurnitureState() 
    {
        return furnitureState;
    }

    public boolean hasAirConditioning() 
    {
        return airConditioning;
    }

    public boolean hasHeating() 
    {
        return heating;
    }

    
}