
package com.dietiEstates.backend.model;

import java.time.LocalDateTime;

import com.dietiEstates.backend.model.embeddable.ExternalRealEstateFeatures;
import com.dietiEstates.backend.model.embeddable.InternalRealEstateFeatures;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;


@Entity(name = "RealEstateForSale")
@Table(name = "real_estate_for_sale")
@PrimaryKeyJoinColumn(name = "real_estate_for_sale_id", foreignKey = @ForeignKey(name = "real_estate_for_sale_fk"))
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@ToString(callSuper = true)
public class RealEstateForSale extends RealEstate 
{
    @Column(name = "selling_price",
            nullable = false, 
            updatable = true)    
    private Double sellingPrice;

    @Column(name = "notary_deed_state",
            nullable = false, 
            updatable = true)    
    private String notaryDeedState;


    
    public RealEstateForSale(String description, LocalDateTime uploadingDate, Double condoFee, String energyClass,
                             InternalRealEstateFeatures internalFeatures, ExternalRealEstateFeatures externalFeatures,
                             Double sellingPrice, String notaryDeedState)
    {
        super(description, uploadingDate, condoFee, energyClass, internalFeatures, externalFeatures);
        this.sellingPrice = sellingPrice;
        this.notaryDeedState = notaryDeedState;
    }
}