package com.dietiEstates.backend.service.auth_service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.stereotype.Service;

import com.dietiEstates.backend.config.JwtService;
import com.dietiEstates.backend.controller.AuthenticationResponse;
import com.dietiEstates.backend.dto.UserAuthDTO;
import com.dietiEstates.backend.dto.UserDTO;
import com.dietiEstates.backend.model.User;
import com.dietiEstates.backend.service.CustomerService;

@Service
public class AuthService {
    private final JwtService jwtService;
    private final AuthServiceFactory authServiceFactory;
    private final CustomerService customerService;
    


    @Autowired
    public AuthService( JwtService jwtService,
                        AuthServiceFactory authServiceFactory,
                        CustomerService customerService)
    {
        this.jwtService=jwtService;
        this.authServiceFactory=authServiceFactory;
        this.customerService=customerService;
        
    }

    public AuthenticationResponse register(UserDTO request) {
    
        User user= customerService.registrate(request);
        
        String jwtToken = jwtService.generateToken(user);
        return new AuthenticationResponse(jwtToken,user.getUsername());
    
    }
    

    public AuthenticationResponse authenticate(UserAuthDTO request) {
        AuthServiceInterface authService = authServiceFactory.getAuthService(request.getRole());
        User user= authService.authenticate(request);
      
        String jwtToken = jwtService.generateToken(user);
        return new AuthenticationResponse(jwtToken,user.getUsername());
        
    }

    public AuthenticationResponse authenticateWithGoogle(OidcUser request) {
        
        User user=customerService.authenticateWithExternalAPI(request);
        // Genera il token di autenticazione
        String token = jwtService.generateToken(user);

        // Crea una risposta di autenticazione
        AuthenticationResponse authenticationResponse = new AuthenticationResponse();
        authenticationResponse.setUsername(request.getAttribute("email"));
        authenticationResponse.setToken(token);
        return authenticationResponse;
    }
        




}