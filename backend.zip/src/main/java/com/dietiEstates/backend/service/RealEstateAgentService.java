package com.dietiEstates.backend.service;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.dietiEstates.backend.dto.UserAuthDTO;
import com.dietiEstates.backend.dto.UserDTO;
import com.dietiEstates.backend.model.Administrator;
import com.dietiEstates.backend.model.RealEstateAgent;
import com.dietiEstates.backend.model.User;
import com.dietiEstates.backend.model.repository.RealEstateAgentRepository;
import com.dietiEstates.backend.service.auth_service.AuthServiceInterface;

import jakarta.transaction.Transactional;

@Service
public class RealEstateAgentService implements AuthServiceInterface {

    private final RealEstateAgentRepository RealEstateAgentRepository;
    private final PasswordValidatorService passwordValidatorService;
    private final AdministratorService administratorService;
    private final PasswordEncoder passwordEncoder;
    private final ModelMapper modelMapper;
    @Autowired
    public RealEstateAgentService(RealEstateAgentRepository RealEstateAgentRepository,
                                PasswordValidatorService passwordValidatorService,
                                AdministratorService administratorService,
                                PasswordEncoder passwordEncoder,
                                ModelMapper modelMapper
                                ){
        this.RealEstateAgentRepository = RealEstateAgentRepository;
        this.passwordValidatorService = passwordValidatorService;
        this.administratorService = administratorService;
        this.passwordEncoder = passwordEncoder;
        this.modelMapper=modelMapper;
    }

    public Optional<RealEstateAgent> findByUsername(String username) {
        return RealEstateAgentRepository.findByUsername(username);
    }

    public RealEstateAgent save(RealEstateAgent RealEstateAgent) {
        if (passwordValidatorService.isValid(RealEstateAgent.getPassword())) {
            RealEstateAgent.setPassword(passwordEncoder.encode(RealEstateAgent.getPassword()));
            return RealEstateAgentRepository.save(RealEstateAgent);
        }
        throw new IllegalArgumentException("Invalid password");
    }

    @Transactional
    public RealEstateAgent saveNewAgent(String username, String password, String usernameAdmin) {
        Optional<RealEstateAgent> RealEstateAgent= findByUsername(username);
            
        if (RealEstateAgent.isPresent()) {
            throw new IllegalArgumentException("Username already in use");
        }
        Optional<Administrator> admin=administratorService.findByUsername(usernameAdmin);  
        if (admin.isEmpty()) {
            throw new IllegalArgumentException("Administrator not found");
        }
        if (passwordValidatorService.isValid(password)) {
            RealEstateAgent RealEstateAgentNew = generateRealEstateAgent(admin.get(), username, password);
            return save(RealEstateAgentNew);
        } else {
            throw new IllegalArgumentException("Invalid password");
        }
    }


    private RealEstateAgent generateRealEstateAgent(Administrator admin, String username, String password) {
        RealEstateAgent RealEstateAgent = new RealEstateAgent();
        RealEstateAgent.setAdministrator(admin);
        RealEstateAgent.setPassword(password);
        RealEstateAgent.setUsername(username);
        return RealEstateAgent;
    }

    @Override
    public User authenticate(UserAuthDTO userAuthDTO) {
        Optional<RealEstateAgent> RealEstateAgent= findByUsername(userAuthDTO.getUsername());
            
        if (RealEstateAgent.isPresent()) {
            RealEstateAgent agent = RealEstateAgent.get();
            if (passwordEncoder.matches(userAuthDTO.getPassword(), agent.getPassword())) {
                return modelMapper.map(agent,User.class);
            } else {
                throw new IllegalArgumentException("Password wrong");
            }
        } else {
                throw new IllegalArgumentException("Email is not registered");
        }
    
    }

    @Override
    public User registrate(UserDTO userDTO) {
        return saveNewAgent(userDTO.getUsername(), userDTO.getPassword(), userDTO.getUsername());
            
    }
}