package com.dietiEstates.backend.service.auth_service;


import com.dietiEstates.backend.dto.UserAuthDTO;
import com.dietiEstates.backend.dto.UserDTO;
import com.dietiEstates.backend.model.User;

public interface AuthServiceInterface {
    User authenticate(UserAuthDTO userAuthDTO);
    User registrate(UserDTO userDTO);
}
