package com.dietiEstates.backend.service.RealEstate_service;

import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dietiEstates.backend.dto.AddressDTO;
import com.dietiEstates.backend.dto.RealEstateForRentDTO;
import com.dietiEstates.backend.model.Address;
import com.dietiEstates.backend.model.RealEstateAgent;
import com.dietiEstates.backend.model.RealEstateForRent;
import com.dietiEstates.backend.model.repository.RealEstateForRentRepository;
import com.dietiEstates.backend.service.AddressService;
import com.dietiEstates.backend.service.RealEstateAgentService;

import jakarta.transaction.Transactional;

@Service
public class RealEstateForRentService implements RealEstateService<RealEstateForRent,RealEstateForRentDTO>{

    private final RealEstateAgentService RealEstateAgentService;
    private final RealEstateForRentRepository RealEstateForRentRepository;
    private final ModelMapper modelMapper;
    private final AddressService addressService;

    @Autowired
    public RealEstateForRentService(RealEstateAgentService RealEstateAgentService,
                               RealEstateForRentRepository RealEstateForRentRepository,
                               ModelMapper modelMapper,
                                AddressService addressService) {
        this.RealEstateAgentService = RealEstateAgentService;
        this.RealEstateForRentRepository = RealEstateForRentRepository;
        this.modelMapper = modelMapper;
        this.addressService=addressService;
    }

    @Override
    @Transactional
    public RealEstateForRentDTO saveNewRealEstate(RealEstateForRentDTO RealEstateForRentDTO,
                                                                  String usernameRealEstateAgent,AddressDTO addressDTO) {
        Optional<RealEstateAgent> agent= RealEstateAgentService.findByUsername(usernameRealEstateAgent);
        
        if (agent.isPresent()) {
                
                Address address= addressService.save(addressDTO);
            
                RealEstateForRent RealEstateForRent = modelMapper.map(RealEstateForRentDTO, RealEstateForRent.class);
                RealEstateForRent.setRealEstateAgent(agent.get());
                RealEstateForRent.setAddress(address);
                RealEstateForRent RealEstateForRentSave= save(RealEstateForRent);
                return modelMapper.map(RealEstateForRentSave,RealEstateForRentDTO.class);
                
        } else {
            throw new IllegalArgumentException("Agent not found");
        }
        
    }

    public Optional<List<RealEstateForRentDTO>> getRealEstateForRents(Long page, Long number) {
        
        return Optional.empty();
    }

    @Override
    public RealEstateForRent save(RealEstateForRent RealEstateForRent)
    {
        return RealEstateForRentRepository.save(RealEstateForRent);
    }

    @Override
    public Optional<RealEstateForRent> findById(Long id)
    {
        return RealEstateForRentRepository.findById(id);
    }
}