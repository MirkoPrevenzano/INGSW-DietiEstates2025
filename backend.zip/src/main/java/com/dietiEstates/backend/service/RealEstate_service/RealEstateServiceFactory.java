package com.dietiEstates.backend.service.RealEstate_service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dietiEstates.backend.dto.RealEstateDTO;
import com.dietiEstates.backend.dto.RealEstateForRentDTO;
import com.dietiEstates.backend.dto.RealEstateForSaleDTO;

@Component
public class RealEstateServiceFactory {

    private final RealEstateForRentService RealEstateForRentService;
    private final RealEstateForSaleService RealEstateForSaleService;

    @Autowired
    public RealEstateServiceFactory(RealEstateForRentService RealEstateForRentService,
                                  RealEstateForSaleService RealEstateForSaleService) {
        this.RealEstateForRentService = RealEstateForRentService;
        this.RealEstateForSaleService = RealEstateForSaleService;
    }

    @SuppressWarnings("rawtypes")
    public RealEstateService getService(RealEstateDTO RealEstateDTO) {
        if (RealEstateDTO instanceof RealEstateForRentDTO) {
            return RealEstateForRentService;
        } else if (RealEstateDTO instanceof RealEstateForSaleDTO) {
            return RealEstateForSaleService;
        } else {
            throw new IllegalArgumentException("Unsupported RealEstate type");
        }
    }
}