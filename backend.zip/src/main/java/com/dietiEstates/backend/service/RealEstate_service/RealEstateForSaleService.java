package com.dietiEstates.backend.service.RealEstate_service;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dietiEstates.backend.dto.AddressDTO;
import com.dietiEstates.backend.dto.RealEstateForSaleDTO;
import com.dietiEstates.backend.model.Address;
import com.dietiEstates.backend.model.RealEstateAgent;
import com.dietiEstates.backend.model.RealEstateForSale;
import com.dietiEstates.backend.model.repository.RealEstateForSaleRepository;
import com.dietiEstates.backend.service.AddressService;
import com.dietiEstates.backend.service.RealEstateAgentService;

@Service
public class RealEstateForSaleService implements RealEstateService<RealEstateForSale, RealEstateForSaleDTO> {
    

    private final RealEstateAgentService RealEstateAgentService;
    private final RealEstateForSaleRepository RealEstateForSaleRepository;
    private final ModelMapper modelMapper;
    private final AddressService addressService;

    @Autowired
    public RealEstateForSaleService(RealEstateAgentService RealEstateAgentService,
                                    RealEstateForSaleRepository RealEstateForSaleRepository,
                                    ModelMapper modelMapper,
                                    AddressService addressService){
        this.RealEstateAgentService=RealEstateAgentService;
        this.RealEstateForSaleRepository=RealEstateForSaleRepository;
        this.modelMapper=modelMapper;
        this.addressService=addressService;
    }

    @Override
    public RealEstateForSaleDTO saveNewRealEstate(RealEstateForSaleDTO RealEstateForSaleDTO,
                                           String usernameRealEstateAgent,
                                           AddressDTO addressDTO) {
        Optional<RealEstateAgent> agent = RealEstateAgentService.findByUsername(usernameRealEstateAgent);

        if (agent.isPresent()) {
            Address address = addressService.save(addressDTO);
            RealEstateForSale RealEstateForSale = modelMapper.map(RealEstateForSaleDTO, RealEstateForSale.class);
            RealEstateForSale.setRealEstateAgent(agent.get());
            
            RealEstateForSale.setAddress(address);
            RealEstateForSale savedRealEstateForSale = save(RealEstateForSale);
            return modelMapper.map(savedRealEstateForSale, RealEstateForSaleDTO.class);
        } else {
            throw new IllegalArgumentException("Agent not found");
        }
    }

    @Override
    public RealEstateForSale save(RealEstateForSale RealEstate)
    {
        return RealEstateForSaleRepository.save(RealEstate);
    }

    @Override
    public Optional<RealEstateForSale> findById(Long id)
    {
        return RealEstateForSaleRepository.findById(id);
    }

    

    

    
}
