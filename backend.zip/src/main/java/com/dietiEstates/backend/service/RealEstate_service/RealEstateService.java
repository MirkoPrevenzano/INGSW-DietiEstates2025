package com.dietiEstates.backend.service.RealEstate_service;

import java.util.Optional;

import com.dietiEstates.backend.dto.AddressDTO;
import com.dietiEstates.backend.dto.RealEstateDTO;
import com.dietiEstates.backend.model.RealEstate;

public interface RealEstateService<T extends RealEstate, R extends RealEstateDTO> {
    public R saveNewRealEstate(R RealEstateForSaleDTO, String usernameRealEstateAgent, AddressDTO addressDTO);
                                                    
    public T save(T RealEstate);
    public Optional<T> findById(Long id);

}
