package com.dietiEstates.backend.service.auth_service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dietiEstates.backend.service.AdministratorService;
import com.dietiEstates.backend.service.CustomerService;
import com.dietiEstates.backend.service.RealEstateAgentService;

@Component
public class AuthServiceFactory {

    private final CustomerService customerService;
    private final AdministratorService administratorAuthService;
    private final RealEstateAgentService RealEstateAgentService;

    @Autowired
    public AuthServiceFactory(CustomerService customerService,
                              AdministratorService administratorAuthService,
                              RealEstateAgentService RealEstateAgentService) {
        this.customerService = customerService;
        this.administratorAuthService = administratorAuthService;
        this.RealEstateAgentService = RealEstateAgentService;
    }

    public AuthServiceInterface getAuthService(String userType) {
        switch (userType.toLowerCase()) {
            case "customer":
                return customerService;
            case "administrator":
                return administratorAuthService;
            case "RealEstateagent":
                return RealEstateAgentService;
            default:
                throw new IllegalArgumentException("Invalid user type: " + userType);
        }
    }
}