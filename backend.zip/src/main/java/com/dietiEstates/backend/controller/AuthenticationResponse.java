package com.dietiEstates.backend.controller;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AuthenticationResponse {
    private String token;
    private String username;

    public AuthenticationResponse(String token,
                                    String username)
    {
        this.token=token;
        this.username=username;
    }
    //solo token

}
