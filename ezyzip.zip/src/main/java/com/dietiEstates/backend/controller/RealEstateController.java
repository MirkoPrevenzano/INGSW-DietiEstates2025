
package com.dietiEstates.backend.controller;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Order;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dietiEstates.backend.model.RealEstate;
import com.dietiEstates.backend.repository.RealEstateRepository;
import com.dietiEstates.backend.service.RealEstateService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;


@RestController
@RequestMapping(path = "/real-estate")
@RequiredArgsConstructor
@Slf4j
public class RealEstateController 
{
    private final RealEstateService realEstateService;
    private final RealEstateRepository realEstateRepository;


    @GetMapping(path = "search")
    public void aa(@RequestParam Map<String,String> filters) 
    {
        //List<RealEstate> realEstates = realEstateService.search(filters);

        List<RealEstate> realEstates2 = realEstateRepository.findAll(Sort.by(Sort.Direction.DESC,"uploadingDate"));

        for(RealEstate realEstate : realEstates2)
            log.info(realEstate.toString());

/*         for(RealEstate realEstate : realEstates)
            log.info(realEstate.toString());  */
    }
}