
package com.dietiEstates.backend.service;

import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.dietiEstates.backend.model.RealEstate;
import com.dietiEstates.backend.model.RealEstateAgent;
import com.dietiEstates.backend.model.embeddable.RealEstateAgentStats;
import com.dietiEstates.backend.model.embeddable.RealEstateStats;
import com.dietiEstates.backend.repository.RealEstateAgentRepository;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;


@Service
@RequiredArgsConstructor
@Slf4j
public class PdfService 
{
    private final RealEstateAgentRepository realEstateAgentRepository;



    public void writePdfResponse(String username, HttpServletResponse response) throws DocumentException, IOException 
    {
        RealEstateAgent realEstateAgent = realEstateAgentRepository.findByUsername(username).get();

        Document document = new Document(PageSize.A4);
        try 
        {  
            PdfWriter.getInstance(document, new FileOutputStream("PDFprova.pdf"));

            document.open();

            Font paragraphFont = createFont(FontFactory.HELVETICA_BOLD, 22, Color.BLUE);
            Font cellHeaderFont = createFont(FontFactory.HELVETICA, 13, Color.WHITE);
            Font cellFont = createFont(FontFactory.HELVETICA, 12, Color.BLACK);
            PdfPCell cellHeader = createCell(Color.BLUE);
            PdfPCell cell = createCell(Color.WHITE);
    
            writeAgentInfo(document, paragraphFont, cellHeaderFont, cellHeader, cellFont, cell, realEstateAgent);
            writeAgentStats(document, paragraphFont, cellHeaderFont, cellHeader, cellFont, cell, realEstateAgent);
            writeRealEstateStats(document, paragraphFont, cellHeaderFont, cellHeader, cellFont, cell, realEstateAgent);

            response.setHeader("Success", "PDF esportato correttamente!"); 
            log.info("PDF esportato correttamente!");
        } 
        catch (DocumentException | IOException e) 
        {
            log.error("Errore durante l'esportazione del PDF!\n" + e.getMessage());
            throw e;
        }
        finally
        {
            document.close();
        }
    }



    private Font createFont(String fontName, float size, Color fontColor) 
    {
        Font font = FontFactory.getFont(fontName);
        font.setSize(size);
        font.setColor(fontColor);

        return font;
    }

    private PdfPCell createCell(Color cellColor) 
    {
        PdfPCell cell = new PdfPCell();
        cell.setBackgroundColor(cellColor);
        cell.setPadding(5);

        return cell;
    }

    private Paragraph createParagraph(Font fontName, String title) 
    {
        Paragraph p = new Paragraph(title, fontName);
        p.setAlignment(Paragraph.ALIGN_CENTER);

        return p;
    }

    private PdfPTable createTable(int columnsNumber, float widthPercentage, float[] relativeWidths) 
    {
        PdfPTable table = new PdfPTable(columnsNumber);
        table.setWidthPercentage(widthPercentage);
        table.setWidths(relativeWidths);
        table.setSpacingBefore(15);
        table.setSpacingAfter(40);

        return table;
    }

    private void writeInTable(PdfPTable table, PdfPCell cell, Font cellFont, String ... headers) 
    {
        for(String header : headers)
        {
            cell.setPhrase(new Phrase(header, cellFont));
            table.addCell(cell);
        }
    } 

    private void writeAgentInfo(Document document, Font paragraphFont, Font cellHeaderFont, PdfPCell cellHeader, 
                                Font cellFont, PdfPCell cell, RealEstateAgent realEstateAgent) 
    {
        Paragraph agentInfoParagraph = createParagraph(paragraphFont, "AGENT INFO");
        PdfPTable agentInfoTable = createTable(3, 80f, new float[] {2.5f, 2.5f, 2.5f});
        String[] agentInfoHeader = {"Name", "Surname", "Username"};
        writeInTable(agentInfoTable, cellHeader, cellHeaderFont, agentInfoHeader);
        String[] agentInfo = {realEstateAgent.getName(), realEstateAgent.getSurname(), realEstateAgent.getUsername()};
        writeInTable(agentInfoTable, cell, cellFont, agentInfo);
        
        document.add(agentInfoParagraph);
        document.add(agentInfoTable);
    }

    private void writeAgentStats(Document document, Font paragraphFont, Font cellHeaderFont, PdfPCell cellHeader, 
                                 Font cellFont, PdfPCell cell, RealEstateAgent realEstateAgent) 
    {
        Paragraph p2 = createParagraph(paragraphFont, "AGENT STATS");
        PdfPTable table2 = createTable(5, 100f, new float[] {2.0f, 2.0f, 2.0f, 2.0f, 2.0f});
        String[] agentStatsHeader = {"Uploaded Real Estates", "Sold Real Estates", "Rented Real Estates", "Sales Income", "Rentals Income" };
        writeInTable(table2, cellHeader, cellHeaderFont, agentStatsHeader);
        RealEstateAgentStats realEstateAgentStats = realEstateAgent.getRealEstateAgentStats();
        String[] agentStats = {((Integer)realEstateAgentStats.getTotalUploadedRealEstates()).toString(), 
                               ((Integer)realEstateAgentStats.getTotalSoldRealEstates()).toString(),
                               ((Integer)realEstateAgentStats.getTotalRentedRealEstates()).toString(),
                               ((Long)realEstateAgentStats.getSalesIncome()).toString(),
                               ((Long)realEstateAgentStats.getRentalsIncome()).toString()};
        writeInTable(table2, cell, cellFont, agentStats);

        document.add(p2);
        document.add(table2);
    }

    private void writeRealEstateStats(Document document, Font paragraphFont, Font cellHeaderFont, PdfPCell cellHeader, 
                                      Font cellFont, PdfPCell cell, RealEstateAgent realEstateAgent) 
    {
        Paragraph p3 = createParagraph(paragraphFont, "REAL ESTATES STATS");
        PdfPTable table3 = createTable(5, 105f, new float[] {3.0f, 2.5f, 2.0f, 2.0f, 2.0f});
        String[] realEstateStatsHeader = {"Title", "Uploading Date", "Views Number", "Offers Number", "Visits Number"};
        writeInTable(table3, cellHeader, cellHeaderFont, realEstateStatsHeader);
        List<RealEstate> realEstates = realEstateAgent.getRealEstates();
        for(RealEstate realEstate : realEstates)
        {
            RealEstateStats realEstateStats = realEstate.getRealEstateStats();
            String[] estateStats = {realEstate.getTitle(),
                                    realEstate.getUploadingDate().toString(),
                                    ((Long)realEstateStats.getViewsNumber()).toString(),
                                    ((Long)realEstateStats.getOffersNumber()).toString(),
                                    ((Long)realEstateStats.getVisitsNumber()).toString()};
    
            writeInTable(table3, cell, cellFont, estateStats);
        }
    
        document.add(p3);
        document.add(table3);
    }
}