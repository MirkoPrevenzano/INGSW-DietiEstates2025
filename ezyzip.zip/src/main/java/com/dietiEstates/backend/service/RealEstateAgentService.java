
package com.dietiEstates.backend.service;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.modelmapper.MappingException;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Limit;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.dietiEstates.backend.dto.RealEstateForRentCreationDTO;
import com.dietiEstates.backend.dto.RealEstateForSaleCreationDTO;
import com.dietiEstates.backend.dto.RecentRealEstateDTO;
import com.dietiEstates.backend.model.Address;
import com.dietiEstates.backend.model.Photo;
import com.dietiEstates.backend.model.RealEstate;
import com.dietiEstates.backend.model.RealEstateAgent;
import com.dietiEstates.backend.model.RealEstateForRent;
import com.dietiEstates.backend.model.RealEstateForSale;
import com.dietiEstates.backend.repository.RealEstateAgentRepository;
import com.dietiEstates.backend.repository.RealEstateRepository;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.core.exception.SdkException;


@Service
@RequiredArgsConstructor
@Slf4j
public class RealEstateAgentService 
{
    private final RealEstateAgentRepository realEstateAgentRepository;
    private final RealEstateRepository realEstateRepository;
    private final S3Service s3Service;
    private final ModelMapper modelMapper;



    @Transactional
    public void createRealEstateForSale(String username, RealEstateForSaleCreationDTO realEstateForSaleCreationDTO)  throws UsernameNotFoundException,
                                                                                                                            MappingException
    {
        Optional<RealEstateAgent> realEstateAgentOptional = realEstateAgentRepository.findByUsername(username);
        if(realEstateAgentOptional.isEmpty())
        {
            log.error("Agent not found in database");
            throw new UsernameNotFoundException("Agent not found in database");
        }
        RealEstateAgent realEstateAgent = realEstateAgentOptional.get();

        RealEstateForSale realEstateForSale;
        try 
        {
            realEstateForSale = modelMapper.map(realEstateForSaleCreationDTO, RealEstateForSale.class);
        } 
        catch (MappingException e) 
        {
            log.error("Problems while mapping! Probably the source object was different than the one expected!");
            throw e;
        }

        Address address = realEstateForSaleCreationDTO.getAddress();
        realEstateForSale.addAddress(address);
        realEstateForSale.setUploadingDate(LocalDateTime.now());

        realEstateAgent.addRealEstate(realEstateForSale);
        realEstateAgentRepository.save(realEstateAgent);

        log.info("Real Estate For Sale was created successfully!");
    }


    @Transactional
    public void createRealEstateForRent(String username, RealEstateForRentCreationDTO realEstateForRentCreationDTO) throws UsernameNotFoundException,
                                                                                                                           MappingException
    {
        Optional<RealEstateAgent> realEstateAgentOptional = realEstateAgentRepository.findByUsername(username);
        if(realEstateAgentOptional.isEmpty())
        {
            log.error("Agent not found in database");
            throw new UsernameNotFoundException("Agent not found in database");
        }
        RealEstateAgent realEstateAgent = realEstateAgentOptional.get();

        RealEstateForRent realEstateForRent;
        try 
        {
            realEstateForRent = modelMapper.map(realEstateForRentCreationDTO, RealEstateForRent.class);
        } 
        catch (MappingException e) 
        {
            log.error("Problems while mapping! Probably the source object was different than the one expected!");
            throw e;
        }

        Address address = realEstateForRentCreationDTO.getAddress();
        realEstateForRent.addAddress(address);
        realEstateForRent.setUploadingDate(LocalDateTime.now());

        realEstateAgent.addRealEstate(realEstateForRent);
        realEstateAgentRepository.save(realEstateAgent);

        log.info("Real Estate For Rent was created successfully!");
    }


    @Transactional
    public String uploadPhoto(String username, MultipartFile file, Long realEstateId) throws IllegalArgumentException, RuntimeException
    {
        Optional<RealEstate> realEstateOptional = realEstateRepository.findById(realEstateId);
        if(realEstateOptional.isEmpty())
        {
            log.error("Real Estate not found in database");
            throw new IllegalArgumentException("Real Estate not found in database");
        }
        RealEstate realEstate = realEstateOptional.get();

        String contentType = file.getContentType();
        Long size = file.getSize();

        log.info("file content type: {}", contentType);
        log.info("file size: {}", size);

        if(contentType != null && !contentType.equals("image/jpeg") && !contentType.equals("image/png"))
        {
            log.error("Photo format is not supported!");
            throw new IllegalArgumentException("Photo format is not supported!");
        }

        if(size >= 10000000)
        {
            log.error("Photo have exceeded the maximum size!");
            throw new IllegalArgumentException("Photo have exceeded the maximum size!");
        }

        String photoKey = UUID.randomUUID().toString();
        try 
        {
            s3Service.putObject("%s".formatted(photoKey), file.getBytes());
        } 
        catch (SdkException | IOException e) 
        {
            log.error("Amazon S3/SDK/IO exception has occurred while putting photo in the bucket!" + e.getMessage());
            throw new RuntimeException("Failed to upload photo!", e);
        }

        Photo photo = new Photo(photoKey);
        realEstate.getPhotos().add(photo);
        realEstateRepository.save(realEstate);
        
        return photoKey;
    }

    
    public byte[] getPhoto(String photoKey) throws IOException
    {
        // TODO: controllare se l'immobile ha foto

        return s3Service.getObject(photoKey);
    }


    public List<RecentRealEstateDTO> findRecentRealEstates(String username, Integer limit) 
    {
        List<RecentRealEstateDTO> recentRealEstatesDTO = realEstateRepository.findRecentRealEstates(realEstateAgentRepository.findByUsername(username).get().getUserId(), limit);

/*         List<RecentRealEstateDTO> recentRealEstatesDTO = new ArrayList<>();
        for(RealEstate realEstate : realEstates)
        {
            try 
            {
                RecentRealEstateDTO recentRealEstateDTO = modelMapper.map(realEstate, RecentRealEstateDTO.class);
                recentRealEstatesDTO.add(recentRealEstateDTO);
            } 
            catch (MappingException e) 
            {
                log.error("Problems while mapping! Probably the source object was different than the one expected!");
                throw e;
            }
        } */

        return recentRealEstatesDTO;
    }


    public List<RecentRealEstateDTO> findRecentRealEstates2(String username, Integer limit) 
    {
        List<RecentRealEstateDTO> recentRealEstatesDTO = realEstateRepository.
                                                         findRecentRealEstates2(realEstateAgentRepository.findByUsername(username).get().getUserId(), 
                                                                                Limit.of(limit));

        return recentRealEstatesDTO;
    }
}