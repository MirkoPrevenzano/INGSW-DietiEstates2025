
package com.dietiEstates.backend.dto;

import com.dietiEstates.backend.model.Address;
import com.dietiEstates.backend.model.embeddable.ExternalRealEstateFeatures;
import com.dietiEstates.backend.model.embeddable.InternalRealEstateFeatures;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;


@Data
@NoArgsConstructor
@RequiredArgsConstructor
public class RealEstateCreationDTO 
{
    @NonNull
    private String title;

    @NonNull
    private String description;
    
    @NonNull
    private Double price;

    @NonNull
    private Double condoFee;
    
    @NonNull
    private String energyClass;

    @NonNull
    private InternalRealEstateFeatures internalRealEstateFeatures;

    @NonNull
    private ExternalRealEstateFeatures externalRealEstateFeatures;

    @NonNull
    private Address address;
}
