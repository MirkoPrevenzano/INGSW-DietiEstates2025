
package com.dietiEstates.backend.model.embeddable;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Embeddable
@Setter
@EqualsAndHashCode
@NoArgsConstructor
@RequiredArgsConstructor
@ToString
public class InternalRealEstateFeatures 
{
    @NonNull
    @Column(name = "size", 
            nullable = false, 
            updatable = true)
    private Double size;

    @NonNull
    @Column(name = "rooms_number", 
            nullable = false, 
            updatable = true)
    private Integer roomsNumber;

    @NonNull
    @Column(name = "estate_condition", 
            nullable = false, 
            updatable = true)
    private String estateCondition;

    @NonNull
    @Column(name = "furniture_condition", 
            nullable = false, 
            updatable = true)
    private String furnitureCondition;

    @Column(name = "has_air_conditioning",
            nullable = true, 
            updatable = true,
            columnDefinition = "boolean default false")     
    private boolean airConditioning;

    @Column(name = "has_heating",
            nullable = true, 
            updatable = true,
            columnDefinition = "boolean default false")  
    private boolean heating;



    public Double getSize() 
    {
        return size;
    }

    public Integer getRoomsNumber() 
    {
        return roomsNumber;
    }

    public String getestateCondition() 
    {
        return estateCondition;
    }

    public String getfurnitureCondition() 
    {
        return furnitureCondition;
    }

    public boolean hasAirConditioning() 
    {
        return airConditioning;
    }

    public boolean hasHeating() 
    {
        return heating;
    }
}