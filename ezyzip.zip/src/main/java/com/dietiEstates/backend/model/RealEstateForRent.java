
package com.dietiEstates.backend.model;

import java.time.LocalDateTime;

import com.dietiEstates.backend.model.embeddable.ExternalRealEstateFeatures;
import com.dietiEstates.backend.model.embeddable.InternalRealEstateFeatures;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;


@Entity(name = "RealEstateForRent")
@Table(name = "real_estate_for_rent")
@PrimaryKeyJoinColumn(name = "real_estate_for_rent_id", foreignKey = @ForeignKey(name = "real_estate_for_rent_fk"))
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@ToString(callSuper = true)
public class RealEstateForRent extends RealEstate
{
    @Column(name = "security_deposit",
            nullable = false, 
            updatable = true)
    private Double securityDeposit;

    @Column(name = "contract_years",
            nullable = false, 
            updatable = true)
    private Integer contractYears;



    public RealEstateForRent(String title,String description, LocalDateTime uploadingDate, Double price, Double condoFee, String energyClass,
                             InternalRealEstateFeatures internalFeatures, ExternalRealEstateFeatures externalFeatures,
                             Double securityDeposit, Integer contractYears)
    {
        super(title,description, uploadingDate, condoFee, price, energyClass, internalFeatures, externalFeatures);
        this.securityDeposit = securityDeposit;
        this.contractYears = contractYears;
    }
}
