
package com.dietiEstates.backend.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.dietiEstates.backend.dto.CountryDTO;
import com.dietiEstates.backend.model.Address;


@Repository
public interface AddressRepository extends JpaRepository<Address,Long>
{    
    @Query(value = "SELECT new com.dietiEstates.backend.dto.CountryDTO(a.country) FROM Address a")
    List<CountryDTO> findCountries(); 
}