
package com.dietiEstates.backend.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import com.dietiEstates.backend.dto.RealEstatePreviewDTO;
import com.dietiEstates.backend.dto.RealEstateRecentDTO;
import com.dietiEstates.backend.dto.RealEstateStatsDTO;
import com.dietiEstates.backend.model.Address;
import com.dietiEstates.backend.model.RealEstate;
import com.dietiEstates.backend.model.RealEstateForRent;
import com.dietiEstates.backend.model.RealEstateForSale;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;

import lombok.extern.slf4j.Slf4j;


@Slf4j
public class CustomRepositoryImpl implements CustomRepository 
{
    @PersistenceContext
    private EntityManager entityManager;



    @Override
    public Page<RealEstatePreviewDTO> findRealEstateByFilters(Map<String,String> filters, Pageable page) 
    {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<RealEstatePreviewDTO> query = cb.createQuery(RealEstatePreviewDTO.class);
        
        Root<RealEstate> realEstate = query.from(RealEstate.class);
        Root<Address> address = query.from(Address.class);
    
        Path<String> energyClass = realEstate.get("energyClass");
        Path<Double> price = realEstate.get("price");
        //VEDERE COME FARE con city
        Path<String> city = address.get("city");
        Path<Integer> roomsNumber = realEstate.get("internalFeatures").get("roomsNumber");
        Path<Boolean> airConditioning = realEstate.get("internalFeatures").get("airConditioning");
        Path<Boolean> heating = realEstate.get("internalFeatures").get("heating");
        Path<Boolean> elevator = realEstate.get("externalFeatures").get("elevator");
        Path<Boolean> concierge = realEstate.get("externalFeatures").get("concierge");
        Path<Boolean> terrace = realEstate.get("externalFeatures").get("terrace");
        Path<Boolean> garage = realEstate.get("externalFeatures").get("garage");
        Path<Boolean> balcony = realEstate.get("externalFeatures").get("balcony");
        Path<Boolean> garden = realEstate.get("externalFeatures").get("garden");
        Path<Boolean> swimmingPool = realEstate.get("externalFeatures").get("swimmingPool");
        Path<Boolean> nearPark = realEstate.get("externalFeatures").get("nearPark");
        Path<Boolean> nearSchool = realEstate.get("externalFeatures").get("nearSchool");
        Path<Boolean> nearPublicTransport = realEstate.get("externalFeatures").get("nearPublicTransport");

        List<Predicate> predicates = new ArrayList<>();


/*         String condoFeeParam = filters.get("condoFee");
        if(condoFeeParam != null)
            predicates.add(cb.gt(condoFee, Double.valueOf(condoFeeParam)));

        String energyClassParam = filters.get("energyClass");
        if(energyClassParam != null)
                predicates.add(cb.equal(energyClass, energyClassParam));

        String sizeParam = filters.get("size");
        if(sizeParam != null)
            predicates.add(cb.gt(size, Double.valueOf(sizeParam)));

        String roomsNumberParam = filters.get("roomsNumber");
        if(roomsNumberParam != null)
            predicates.add(cb.gt(roomsNumber, Integer.valueOf(roomsNumberParam)));

        String airConditioningParam = filters.get("airConditioning");
        if(airConditioningParam != null)
                predicates.add(cb.equal(airConditioning, Boolean.valueOf(airConditioningParam)));
         
        String heatingParam = filters.get("heating");
        if(heatingParam != null)
                predicates.add(cb.equal(heating, Boolean.valueOf(heatingParam)));
         
        String elevatorParam = filters.get("elevator");
        if(elevatorParam != null)
                predicates.add(cb.equal(elevator, Boolean.valueOf(elevatorParam)));
         
        String conciergeParam = filters.get("concierge");
        if(conciergeParam != null)
                predicates.add(cb.equal(concierge, Boolean.valueOf(conciergeParam)));
         
        String terraceParam = filters.get("terrace");
        if(terraceParam != null)
            predicates.add(cb.equal(terrace, Boolean.valueOf(terraceParam)));
        
        String garageParam = filters.get("garage");
        if(garageParam != null)
            predicates.add(cb.equal(garage, Boolean.valueOf(garageParam)));
         
        String balconyParam = filters.get("balcony");
        if(balconyParam != null)
            predicates.add(cb.equal(balcony, Boolean.valueOf(balconyParam)));

        String gardenParam = filters.get("garden");
        if(gardenParam != null)
            predicates.add(cb.equal(garden, Boolean.valueOf(gardenParam)));

        String swimmingPoolParam = filters.get("swimmingPool");
        if(swimmingPoolParam != null)
            predicates.add(cb.equal(swimmingPool, Boolean.valueOf(swimmingPoolParam))); */
              
        for(Map.Entry<String,String> entry : filters.entrySet())
        {
            if(entry.getKey().equals("minPrice"))
            {
                predicates.add(cb.ge(price, Double.valueOf(entry.getValue())));
            } 

            if(entry.getKey().equals("maxPrice"))
            {
                predicates.add(cb.le(price, Double.valueOf(entry.getValue())));
            } 

            if(entry.getKey().equals("energyClass"))
            {
                predicates.add(cb.equal(energyClass, entry.getValue()));
            } 

            if(entry.getKey().equals("roomsNumber"))
            {
                predicates.add(cb.gt(roomsNumber, Integer.valueOf(entry.getValue())));
            }  

            if(entry.getKey().equals("airConditioning"))
            {
                predicates.add(cb.equal(airConditioning, Boolean.valueOf(entry.getValue())));
            }  

            if(entry.getKey().equals("heating"))
            {
                predicates.add(cb.equal(heating, Boolean.valueOf(entry.getValue())));
            }  

            if(entry.getKey().equals("elevator"))
            {
                predicates.add(cb.equal(elevator, Boolean.valueOf(entry.getValue())));
            }

            if(entry.getKey().equals("concierge"))
            {
                predicates.add(cb.equal(concierge, Boolean.valueOf(entry.getValue())));
            }  

            if(entry.getKey().equals("terrace"))
            {
                predicates.add(cb.equal(terrace, Boolean.valueOf(entry.getValue())));
            }  

            if(entry.getKey().equals("garage"))
            {
                predicates.add(cb.equal(garage, Boolean.valueOf(entry.getValue())));
            }  

            if(entry.getKey().equals("balcony"))
            {
                predicates.add(cb.equal(balcony, Boolean.valueOf(entry.getValue())));
            }  

            if(entry.getKey().equals("garden"))
            {
                predicates.add(cb.equal(garden, Boolean.valueOf(entry.getValue())));
            }  

            if(entry.getKey().equals("swimmingPool"))
            {
                predicates.add(cb.equal(swimmingPool, Boolean.valueOf(entry.getValue())));
            }  

            if(entry.getKey().equals("nearPark"))
            {
                predicates.add(cb.equal(nearPark, Boolean.valueOf(entry.getValue())));
            } 

            if(entry.getKey().equals("nearSchool"))
            {
                predicates.add(cb.equal(nearSchool, Boolean.valueOf(entry.getValue())));
            }  

            if(entry.getKey().equals("nearPublicTransport"))
            {
                predicates.add(cb.equal(nearPublicTransport, Boolean.valueOf(entry.getValue())));
            }  
            
            if(entry.getKey().equals("city"))
            {
                predicates.add(cb.equal(city, entry.getValue()));
            } 
        } 

        CriteriaQuery<Long> countQuery = cb.createQuery(Long.class);
        Root<RealEstate> filteredRealEstatesCount = countQuery.from(RealEstate.class);
        countQuery.select(cb.count(filteredRealEstatesCount))
                  .where(cb.and(predicates.toArray(new Predicate[predicates.size()])));

        Long count = entityManager.createQuery(countQuery).getSingleResult();


        Root<RealEstateForSale> realEstateForSale;
        Root<RealEstateForRent> realEstateForRent;

        String realEstateType = filters.get("type");
        //realEstate = factory.getTypeQuery(realEstateType);
        if(realEstateType != null && realEstateType.equals("sale"))
        {
            realEstateForSale = query.from(RealEstateForSale.class);
            predicates.add(cb.equal(realEstate.get("realEstateId"), realEstateForSale.get("realEstateId")));
            predicates.add(cb.equal(realEstate.get("realEstateId"), address.get("addressId")));
            query.select(cb.construct(RealEstatePreviewDTO.class, realEstate.get("realEstateId"),
                                                                              realEstate.get("title"),
                                                                              realEstate.get("description"),
                                                                              realEstate.get("price"),
                                                                              address.get("street"),
                                                                              address.get("longitude"),
                                                                              address.get("latitude")))
                 .where(cb.and(predicates.toArray(new Predicate[predicates.size()])));
        }
        else if(realEstateType != null && realEstateType.equals("rent"))
        {
            realEstateForRent = query.from(RealEstateForRent.class);
            predicates.add(cb.equal(realEstate.get("realEstateId"), realEstateForRent.get("realEstateId")));
            predicates.add(cb.equal(realEstate.get("realEstateId"), address.get("addressId")));
            query.select(cb.construct(RealEstatePreviewDTO.class, realEstate.get("realEstateId"),
                                                                              realEstate.get("title"),
                                                                              realEstate.get("description"),
                                                                              realEstate.get("price"),
                                                                              address.get("street"),
                                                                              address.get("longitude"),
                                                                              address.get("latitude")))                 
                .where(cb.and(predicates.toArray(new Predicate[predicates.size()])));
        }

        Integer count2 = entityManager.createQuery(query).getResultList().size();

        List<RealEstatePreviewDTO> list = entityManager.createQuery(query).setFirstResult((int)page.getOffset()).setMaxResults(page.getPageSize())
                            .getResultList();


        log.info("count : {}",count.toString());
        log.info("count2 : {}",count2.toString());

        PageImpl<RealEstatePreviewDTO> pageImpl = new PageImpl<>(list, page, count2);
        return pageImpl;
    }



    @Override
    public List<RealEstatePreviewDTO> findRealEstateByFilters2(Map<String,String> filters, Pageable page) 
    {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<RealEstatePreviewDTO> query = cb.createQuery(RealEstatePreviewDTO.class);
        
        Root<RealEstate> realEstate = query.from(RealEstate.class);
        Root<Address> address = query.from(Address.class);
    
        Path<String> energyClass = realEstate.get("energyClass");
        Path<Double> price = realEstate.get("price");
        //VEDERE COME FARE con city
        Path<String> city = address.get("city");
        Path<Integer> roomsNumber = realEstate.get("internalFeatures").get("roomsNumber");
        Path<Boolean> airConditioning = realEstate.get("internalFeatures").get("airConditioning");
        Path<Boolean> heating = realEstate.get("internalFeatures").get("heating");
        Path<Boolean> elevator = realEstate.get("externalFeatures").get("elevator");
        Path<Boolean> concierge = realEstate.get("externalFeatures").get("concierge");
        Path<Boolean> terrace = realEstate.get("externalFeatures").get("terrace");
        Path<Boolean> garage = realEstate.get("externalFeatures").get("garage");
        Path<Boolean> balcony = realEstate.get("externalFeatures").get("balcony");
        Path<Boolean> garden = realEstate.get("externalFeatures").get("garden");
        Path<Boolean> swimmingPool = realEstate.get("externalFeatures").get("swimmingPool");
        Path<Boolean> nearPark = realEstate.get("externalFeatures").get("nearPark");
        Path<Boolean> nearSchool = realEstate.get("externalFeatures").get("nearSchool");
        Path<Boolean> nearPublicTransport = realEstate.get("externalFeatures").get("nearPublicTransport");

        List<Predicate> predicates = new ArrayList<>();
              
        for(Map.Entry<String,String> entry : filters.entrySet())
        {
            if(entry.getKey().equals("minPrice"))
            {
                predicates.add(cb.ge(price, Double.valueOf(entry.getValue())));
            } 

            if(entry.getKey().equals("maxPrice"))
            {
                predicates.add(cb.le(price, Double.valueOf(entry.getValue())));
            } 

            if(entry.getKey().equals("energyClass"))
            {
                predicates.add(cb.equal(energyClass, entry.getValue()));
            } 

            if(entry.getKey().equals("roomsNumber"))
            {
                predicates.add(cb.gt(roomsNumber, Integer.valueOf(entry.getValue())));
            }  

            if(entry.getKey().equals("airConditioning"))
            {
                predicates.add(cb.equal(airConditioning, Boolean.valueOf(entry.getValue())));
            }  

            if(entry.getKey().equals("heating"))
            {
                predicates.add(cb.equal(heating, Boolean.valueOf(entry.getValue())));
            }  

            if(entry.getKey().equals("elevator"))
            {
                predicates.add(cb.equal(elevator, Boolean.valueOf(entry.getValue())));
            }

            if(entry.getKey().equals("concierge"))
            {
                predicates.add(cb.equal(concierge, Boolean.valueOf(entry.getValue())));
            }  

            if(entry.getKey().equals("terrace"))
            {
                predicates.add(cb.equal(terrace, Boolean.valueOf(entry.getValue())));
            }  

            if(entry.getKey().equals("garage"))
            {
                predicates.add(cb.equal(garage, Boolean.valueOf(entry.getValue())));
            }  

            if(entry.getKey().equals("balcony"))
            {
                predicates.add(cb.equal(balcony, Boolean.valueOf(entry.getValue())));
            }  

            if(entry.getKey().equals("garden"))
            {
                predicates.add(cb.equal(garden, Boolean.valueOf(entry.getValue())));
            }  

            if(entry.getKey().equals("swimmingPool"))
            {
                predicates.add(cb.equal(swimmingPool, Boolean.valueOf(entry.getValue())));
            }  

            if(entry.getKey().equals("nearPark"))
            {
                predicates.add(cb.equal(nearPark, Boolean.valueOf(entry.getValue())));
            } 

            if(entry.getKey().equals("nearSchool"))
            {
                predicates.add(cb.equal(nearSchool, Boolean.valueOf(entry.getValue())));
            }  

            if(entry.getKey().equals("nearPublicTransport"))
            {
                predicates.add(cb.equal(nearPublicTransport, Boolean.valueOf(entry.getValue())));
            }  
            
            if(entry.getKey().equals("city"))
            {
                predicates.add(cb.equal(city, entry.getValue()));
            } 
        } 

        Root<RealEstateForSale> realEstateForSale;
        Root<RealEstateForRent> realEstateForRent;

        String realEstateType = filters.get("type");
        //realEstate = factory.getTypeQuery(realEstateType);
        if(realEstateType != null && realEstateType.equals("sale"))
        {
            realEstateForSale = query.from(RealEstateForSale.class);
            predicates.add(cb.equal(realEstate.get("realEstateId"), realEstateForSale.get("realEstateId")));
            predicates.add(cb.equal(realEstate.get("realEstateId"), address.get("addressId")));
            query.select(cb.construct(RealEstatePreviewDTO.class, realEstate.get("realEstateId"),
                                                                              realEstate.get("title"),
                                                                              realEstate.get("description"),
                                                                              realEstate.get("price"),
                                                                              address.get("street"),
                                                                              address.get("longitude"),
                                                                              address.get("latitude")))
                 .where(cb.and(predicates.toArray(new Predicate[predicates.size()])));
        }
        else if(realEstateType != null && realEstateType.equals("rent"))
        {
            realEstateForRent = query.from(RealEstateForRent.class);
            predicates.add(cb.equal(realEstate.get("realEstateId"), realEstateForRent.get("realEstateId")));
            predicates.add(cb.equal(realEstate.get("realEstateId"), address.get("addressId")));
            query.select(cb.construct(RealEstatePreviewDTO.class, realEstate.get("realEstateId"),
                                                                              realEstate.get("title"),
                                                                              realEstate.get("description"),
                                                                              realEstate.get("price"),
                                                                              address.get("street"),
                                                                              address.get("longitude"),
                                                                              address.get("latitude")))                 
                .where(cb.and(predicates.toArray(new Predicate[predicates.size()])));
        }

        List<RealEstatePreviewDTO> list = entityManager.createQuery(query).setFirstResult((int)page.getOffset()).setMaxResults(page.getPageSize())
                            .getResultList();

        return list;
    }


    @Override
    public List<RealEstateRecentDTO> findRecentRealEstates(Long agentId, Integer limit) 
    {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<RealEstateRecentDTO> query = cb.createQuery(RealEstateRecentDTO.class);
        
        Root<RealEstate> realEstate = query.from(RealEstate.class);
    
        query.select(cb.construct(RealEstateRecentDTO.class, realEstate.get("realEstateId"), realEstate.get("title"), realEstate.get("description"), realEstate.get("uploadingDate")))
             .where(cb.equal(realEstate.get("realEstateAgent").get("userId"), agentId))
             .orderBy(cb.desc(realEstate.get("uploadingDate")));

        return entityManager.createQuery(query)
                            .setMaxResults(limit)
                            .getResultList();
    }


    @Override
    public List<RealEstateStatsDTO> findRealEstateStats2(Long agentId, Pageable page) 
    {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<RealEstateStatsDTO> query = cb.createQuery(RealEstateStatsDTO.class);
        
        Root<RealEstate> realEstate = query.from(RealEstate.class);
    
        query.select(cb.construct(RealEstateStatsDTO.class, realEstate.get("realEstateId"), 
                                                                         realEstate.get("title"), 
                                                                         realEstate.get("uploadingDate"), 
                                                                         realEstate.get("realEstateStats").get("viewsNumber"),
                                                                         realEstate.get("realEstateStats").get("visitsNumber"),
                                                                         realEstate.get("realEstateStats").get("offersNumber")))
             .where(cb.equal(realEstate.get("realEstateAgent").get("userId"), agentId))
             .orderBy(cb.asc(realEstate.get("realEstateId")));

        List<RealEstateStatsDTO> list = entityManager.createQuery(query)
                                                     .setFirstResult((int)page.getOffset())
                                                     .setMaxResults(page.getPageSize())
                                                     .getResultList();

        return list;
    }                                            

}



/* @Override
public List<RealEstateRecentDTO> findRecentRealEstates(Long agentId, Integer limit) 
{
    CriteriaBuilder cb = entityManager.getCriteriaBuilder();
    CriteriaQuery<RealEstateRecentDTO> query = cb.createQuery(RealEstateRecentDTO.class);
    
    Root<RealEstate> realEstate = query.from(RealEstate.class);
    Root<Address> address = query.from(Address.class);

    List<Predicate> predicates = new ArrayList<>();

    predicates.add(cb.equal(realEstate.get("realEstateAgent").get("userId"), agentId));
    predicates.add(cb.equal(realEstate.get("realEstateId"), address.get("addressId")));

    query.select(cb.construct(RealEstateRecentDTO.class, realEstate.get("realEstateId"), address.get("country"), realEstate.get("description"), realEstate.get("uploadingDate")))
         .where(cb.and(predicates.toArray(new Predicate[predicates.size()])))
         .orderBy(cb.desc(realEstate.get("uploadingDate")));

    return entityManager.createQuery(query)
                        .setMaxResults(limit)
                        .getResultList();
} */