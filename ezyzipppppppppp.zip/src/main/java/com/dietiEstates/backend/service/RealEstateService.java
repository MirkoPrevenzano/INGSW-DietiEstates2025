
package com.dietiEstates.backend.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.dietiEstates.backend.model.RealEstate;
import com.dietiEstates.backend.repository.RealEstateRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;


@Service
@RequiredArgsConstructor
@Slf4j
public class RealEstateService 
{
    private final RealEstateRepository realEstateRepository;



    public List<RealEstate> search(Map<String,String> filters)
    {
        return realEstateRepository.findRealEstateByFilters(filters);
    }
}