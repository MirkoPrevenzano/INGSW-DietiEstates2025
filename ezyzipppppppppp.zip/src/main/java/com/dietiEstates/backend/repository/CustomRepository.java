
package com.dietiEstates.backend.repository;

import java.util.List;
import java.util.Map;

import com.dietiEstates.backend.dto.RecentRealEstateDTO;
import com.dietiEstates.backend.model.RealEstate;


public interface CustomRepository 
{
    List<RealEstate> findRealEstateByFilters(Map<String,String> filters);
    List<RecentRealEstateDTO> findRecentRealEstates(Long agentId, Integer limit);
}