
package com.dietiEstates.backend.controller;


import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dietiEstates.backend.model.RealEstate;
import com.dietiEstates.backend.service.RealEstateService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;


@RestController
@RequestMapping(path = "/real-estate")
@RequiredArgsConstructor
@Slf4j
public class RealEstateController 
{
    private final RealEstateService realEstateService;



    @GetMapping(path = "search")
    public void aa(@RequestParam Map<String,String> filters) 
    {
        List<RealEstate> realEstates = realEstateService.search(filters);

        for(RealEstate realEstate : realEstates)
            log.info(realEstate.toString());
    }
}
