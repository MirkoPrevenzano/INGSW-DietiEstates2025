
package com.dietiEstates.backend.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dietiEstates.backend.dto.RealEstateForRentCreationDTO;
import com.dietiEstates.backend.dto.RealEstateForSaleCreationDTO;
import com.dietiEstates.backend.dto.RecentRealEstateDTO;
import com.dietiEstates.backend.model.RealEstate;
import com.dietiEstates.backend.service.RealEstateAgentService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;


@RestController
@RequestMapping(path = "/agent")
@RequiredArgsConstructor
@Slf4j
public class RealEstateAgentController 
{
    private final RealEstateAgentService realEstateAgentService;



    @PostMapping(path = "{username}/create-real-estate-for-sale")
    public ResponseEntity<?> createRealEstateForSale(@PathVariable String username, @RequestBody RealEstateForSaleCreationDTO realEstateForSaleCreationDTO) 
    {
        try 
        {
            realEstateAgentService.createRealEstateForSale(username, realEstateForSaleCreationDTO);
            return ResponseEntity.status(HttpStatus.CREATED.value()).build();
        } 
        catch (UsernameNotFoundException e)
        {
            return ResponseEntity.notFound().header("Error", e.getMessage()).build();
        }
    }


    @PostMapping(path = "{username}/create-real-estate-for-rent")
    public ResponseEntity<?> createRealEstateForRent(@PathVariable String username, @RequestBody RealEstateForRentCreationDTO realEstateForRentCreationDTO) 
    {
        try 
        {
            realEstateAgentService.createRealEstateForRent(username, realEstateForRentCreationDTO);
            return ResponseEntity.status(HttpStatus.CREATED.value()).build();
        } 
        catch (UsernameNotFoundException e)
        {
            return ResponseEntity.notFound().header("Error", e.getMessage()).build();
        }
    }

    
    @GetMapping(path = "{username}/recent-real-estates/{limit}")
    public void aa(@PathVariable("username") String username, @PathVariable("limit") Integer limit) 
    {
        List<RecentRealEstateDTO> realEstates = realEstateAgentService.findRecentRealEstates(username, limit);

        for(RecentRealEstateDTO recentRealEstateDTO : realEstates)
            log.info(recentRealEstateDTO.toString());
    }
}
