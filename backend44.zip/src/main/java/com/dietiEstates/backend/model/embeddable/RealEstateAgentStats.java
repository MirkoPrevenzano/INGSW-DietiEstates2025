
package com.dietiEstates.backend.model.embeddable;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.Transient;
import lombok.Data;
import lombok.NoArgsConstructor;


@Embeddable
@Data
@NoArgsConstructor
public class RealEstateAgentStats 
{
    @Column(name = "total_uploaded_real_estates", 
            nullable = true,
            updatable = true,
            columnDefinition = "int default 0")
    private int totalUploadedRealEstates;

    @Column(name = "total_sold_real_estates", 
            nullable = true,
            updatable = true,
            columnDefinition = "int default 0")
    private int totalSoldRealEstates;    
    
    @Column(name = "total_rented_real_estates", 
            nullable = true,
            updatable = true,
            columnDefinition = "int default 0")
    private int totalRentedRealEstates;

    @Column(name = "sales_income", 
            nullable = true,
            updatable = true,
            columnDefinition = "bigint default 0")
    private long salesIncome;

    @Column(name = "rentals_income", 
            nullable = true,
            updatable = true,
            columnDefinition = "bigint default 0")
    private long rentalsIncome;

//     @Transient
//     private long totalViewsNumber;

//     @Transient
//     private long totalVisitsNumber;
    
//     @Transient
//     private long totalOffersNumber;

    @Transient
    private long totalIncomes;  

    @Transient
    private long successRate;  

    @Transient
    private long salesToRentalsRatio;
}                       