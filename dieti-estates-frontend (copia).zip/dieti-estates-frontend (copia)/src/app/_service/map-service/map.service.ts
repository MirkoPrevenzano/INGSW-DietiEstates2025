import { ElementRef, Injectable } from '@angular/core';
import { Browser, map, Map, marker, Marker, tileLayer } from 'leaflet';
import { Coordinate } from '../../model/coordinate';

@Injectable({
  providedIn: 'root'
})
export class MapService {
  private readonly geoapifyKey = 'c0324c2c2afb488980eae981c7906a43'; // Sostituisci con la tua chiave API di Geoapify
  private mapInstance!: Map
  private markerInstance!: Marker

  constructor() { }

  initMap(mapElement: ElementRef<HTMLElement>, initCoord: Coordinate, initZoom: number): Map{
    this.mapInstance = map(mapElement.nativeElement).setView(
      [initCoord.lat, initCoord.lon], 
      initZoom
    )

    const isRetina = Browser.retina;
    const baseUrl =
      `https://maps.geoapify.com/v1/tile/osm-bright/{z}/{x}/{y}.png?apiKey=${this.geoapifyKey}`;
    const retinaUrl =
      `https://maps.geoapify.com/v1/tile/osm-bright/{z}/{x}/{y}@2x.png?apiKey=${this.geoapifyKey}`;
      
    tileLayer(isRetina ? retinaUrl : baseUrl, {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(this.mapInstance);
    
    setTimeout(() => {
      this.mapInstance.invalidateSize();
    }, 100);

    return this.mapInstance
  }

  addMarker(coordinate: Coordinate){
    this.checkIstance()  


    if(this.markerInstance)
      this.mapInstance.removeLayer(this.markerInstance)

    this.markerInstance = marker([
      coordinate.lat,
      coordinate.lon
    ]).addTo(this.mapInstance)

    this.mapInstance.setView([
      coordinate.lat,
      coordinate.lon
    ], 20)
  }

  onClickMap(callback: (coordinate: Coordinate)=> void):void{
    this.checkIstance()  

    this.mapInstance.on('click', (event:any)=>{
      callback({lat:event.latlng.lat, lon:event.latlng.lng})
    });
  }

  checkIstance(){
    if (!this.mapInstance) {
      console.error('Map instance is not initialized');
    }
  }
}
