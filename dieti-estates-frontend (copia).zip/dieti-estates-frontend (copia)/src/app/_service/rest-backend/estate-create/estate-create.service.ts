import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EstateSell } from '../../../model/estateSell';
import { EstateRent } from '../../../model/estateRent';
import { Observable } from 'rxjs';
import { Estate } from '../../../model/estate';

@Injectable({
  providedIn: 'root'
})
export class EstateCreateService {
  private readonly url = 'http://localhost:8080/agent';

  constructor(private readonly http: HttpClient) {}

  private readonly httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  createEstate(estate: Estate): Observable<any> {
    const userId = localStorage.getItem('user');
    let endpoint = '';

    switch (estate.type) {
      case 'For Sale':
        endpoint = 'create-real-estate-for-sale';
        break;
      case 'For Rent':
        endpoint = 'create-real-estate-for-rent';
        break;
      default:
        throw new Error('Unknown estate type');
    }

    const url = `${this.url}/${userId}/${endpoint}`;
    return this.http.post(url, estate, this.httpOptions);
  }
}
