import { Component } from '@angular/core';
import { RegisterComponent } from '../register/register.component';
import { RegisterValidationService } from '../../../_service/register-validation/register-validation.service';
import { RegisterService } from '../../../_service/rest-backend/register/register.service';
import { ReactiveFormsModule } from '@angular/forms';
import { RegisterRequest } from '../../../model/registerRequest';
import { CommonModule } from '@angular/common';
import { FormFieldComponent } from '../../form-field/form-field.component';
import { PasswordFieldComponent } from '../../password-field/password-field.component';
import { Router } from '@angular/router';
import {  ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-customer-registrate',
  imports: [
    ReactiveFormsModule, 
    CommonModule,
    FormFieldComponent,
    PasswordFieldComponent
  ],
  templateUrl: '../register/register.component.html',
  styleUrl: './customer-registrate.component.scss'
})
export class CustomerRegistrateComponent extends RegisterComponent{
  
  constructor(
    private readonly register: RegisterService,
    protected override readonly registerValidation: RegisterValidationService,
    protected override readonly notify: ToastrService,
    private readonly router: Router
  ) {
    super(registerValidation, notify);
  }
  
  protected override onRegisterUser(userRequest: RegisterRequest): void {
    if(this.registerValidation.isEmailInvalid(this.registerForm!.value.username))
    {
      this.notify.warning('E-mail not valid')
    }
    else{
      this.register.registrate(userRequest).subscribe({
        error: (err)=>{
          this.notify.error(err)
        },
        complete: ()=>{
          this.router.navigateByUrl('login')
        }
      })
    }
  }

  
  
}

