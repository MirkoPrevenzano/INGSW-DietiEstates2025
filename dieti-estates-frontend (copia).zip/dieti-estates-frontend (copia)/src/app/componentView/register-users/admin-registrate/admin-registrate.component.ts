import { Component, inject } from '@angular/core';
import { RegisterComponent } from '../register/register.component';
import { RegisterRequest } from '../../../model/registerRequest';
import { SavePersonalService } from '../../../_service/rest-backend/save-personal/save-personalservice';
import {  ReactiveFormsModule } from '@angular/forms';
import { RegisterValidationService } from '../../../_service/register-validation/register-validation.service';
import { FormFieldComponent } from '../../form-field/form-field.component';
import { CommonModule } from '@angular/common';
import { PasswordFieldComponent } from '../../password-field/password-field.component';
import {  ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-admin-registrate',
  imports: [
    ReactiveFormsModule,
    FormFieldComponent, 
    CommonModule,
    PasswordFieldComponent
    
  ],
  templateUrl: '../register/register.component.html',
  styleUrl: './admin-registrate.component.scss'
})
export class AdminRegistrateComponent extends RegisterComponent{
  private readonly savePersonalService = inject(SavePersonalService)

  constructor(
    protected override readonly registerValidation: RegisterValidationService,
    protected override readonly notify: ToastrService, 
  ){
    super(registerValidation, notify);
  }

  protected override onRegisterUser(userRequest: RegisterRequest): void {
    this.savePersonalService.saveAdmin(userRequest).subscribe({
      error: (err)=>{
        console.log("Error register:"+err)
        this.notify.error(err)
      },
      complete: ()=>{
        this.notify.success('Admin created successfully')
      }
    })
  }


  
}
