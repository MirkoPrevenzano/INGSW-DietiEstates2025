import { Component, inject } from '@angular/core';
import { RegisterComponent } from '../register/register.component';
import { SavePersonalService } from '../../../_service/rest-backend/save-personal/save-personalservice';
import { ReactiveFormsModule } from '@angular/forms';
import { RegisterRequest } from '../../../model/registerRequest';
import { FormFieldComponent } from '../../form-field/form-field.component';
import { CommonModule } from '@angular/common';
import { PasswordFieldComponent } from '../../password-field/password-field.component';

@Component({
  selector: 'app-agent-registrate',
  imports: [
    ReactiveFormsModule,
    FormFieldComponent, 
    CommonModule,
    PasswordFieldComponent
  ],
  templateUrl: '../register/register.component.html',
})

export class AgentRegistrateComponent extends RegisterComponent{
  private readonly savePersonalService = inject(SavePersonalService)

  protected override onRegisterUser(userRequest: RegisterRequest): void {
    this.savePersonalService.saveAgent(userRequest).subscribe({
      error: (err)=>{
        this.notify.error(err.error)
        console.log(err)
      },
      complete:()=> {
        this.notify.success('agent add with success')
      }     
    })
  }
}

