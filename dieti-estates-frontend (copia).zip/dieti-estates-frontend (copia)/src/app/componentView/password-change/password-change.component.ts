import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators,  } from '@angular/forms';
import { PasswordChangeService } from '../../_service/rest-backend/password-change/password-change.service';
import { PasswordFieldComponent } from '../password-field/password-field.component';
import { PasswordValidatorService } from '../../_service/password-validator/password-validator.service';

@Component({
    selector: 'app-password-change',
    imports: [
      ReactiveFormsModule, 
      CommonModule, 
      PasswordFieldComponent
    ],
    templateUrl: './password-change.component.html',
    styleUrl: './password-change.component.scss'
})
export class PasswordChangeComponent {
    constructor(
      private readonly passwordService:PasswordChangeService,
      private readonly passwordValidatorService:PasswordValidatorService
    ){}

    passwordForm = new FormGroup({
      oldPassword: new FormControl('', [Validators.required]),
      newPassword: new FormControl('', [Validators.required, Validators.minLength(8)]),
      confirmNewPassword: new FormControl('', [Validators.required])
    });

    onChangePassword(){
      if(this.isMatch())
      {
        if(this.isValidNewPassword()){
          this.passwordService.passwordChange({
            oldPassword: this.passwordForm.value.oldPassword as string,
            newPassword: this.passwordForm.value.newPassword as string,
            }).subscribe({
            error: (err)=>{
              console.log(err)
            },
            complete: ()=>{
              console.log("success change password")
            }

          })
        }
      }
    }


    isMatch(){
      const newPassword= this.passwordForm.value.newPassword;
      const confirmPassword= this.passwordForm.value.confirmNewPassword
      return newPassword === confirmPassword;
    }

    isValidNewPassword() {
      const newPassword: string = this.passwordForm.value.newPassword ?? '';
      if(newPassword && newPassword!==''){
        const error= this.passwordValidatorService.validatePassword(newPassword);
        if(error.length == 0 )
          return true
        else
          console.log(error)
      }
      else if(!this.isMatch())
        console.log("Password should be match")
      else
        console.log("Fill new password fields")
      return false
    }
}


