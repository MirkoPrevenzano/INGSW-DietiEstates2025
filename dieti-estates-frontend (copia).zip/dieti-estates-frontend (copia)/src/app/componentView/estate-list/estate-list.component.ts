import { Component, Input } from '@angular/core';
import { EstateItemComponent } from '../_estate-view/estate-item-detail/estate-item-detail.component';
import { CommonModule } from '@angular/common';
import { EstateDescribe } from '../../model/estateDescribe';

@Component({
  selector: 'app-estate-list',
  imports: [
    EstateItemComponent,
    CommonModule
  ],
  templateUrl: './estate-list.component.html',
  styleUrl: './estate-list.component.scss'
})
export class EstateListComponent {
  @Input() listPhotos!:string[][]
  @Input() listEstateDescribe!: EstateDescribe[]
  @Input() listRealEstateId!: number[]
  
}
