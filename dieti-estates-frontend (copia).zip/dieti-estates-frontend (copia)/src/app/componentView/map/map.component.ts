import { AfterViewInit, Component, ElementRef, EventEmitter, Input, OnChanges, Output, SimpleChanges, ViewChild } from '@angular/core';
import { Browser, map, Map, tileLayer, marker, Marker } from 'leaflet';
import { Coordinate } from '../../model/coordinate';
import { EstateLocationFeatures } from '../../model/estateLocationFeatures';
import { MapService } from '../../_service/map-service/map.service';
import { PoiService } from '../../_service/map-service/poi-service/poi.service';

@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.scss']
})
export class MapComponent implements AfterViewInit, OnChanges {
  @ViewChild('map') private readonly mapElement!: ElementRef<HTMLElement>
  @Input() coordinates?: Coordinate
  @Output() coordinateWithMarker = new EventEmitter<Coordinate>()
  @Output() nearbyPOI = new EventEmitter<EstateLocationFeatures>()
  private readonly geoapifyKey = 'c0324c2c2afb488980eae981c7906a43'; // Sostituisci con la tua chiave API di Geoapify
 
  private mapInitialized = false;

  constructor(
    private readonly mapService: MapService,

  ) {}

  ngAfterViewInit() {
    const initCoord: Coordinate ={lat:11, lon:49}
    const initZoom = 4
    this.mapService.initMap(this.mapElement,initCoord,initZoom)
    this.mapService.onClickMap((coordinate:Coordinate)=>{
      this.addMarker(coordinate)
    })

    this.mapInitialized = true;
    if (this.coordinates) {
      this.addMarker(this.coordinates);
    }

  }

  addMarker(coordinate: Coordinate) {
    this.mapService.addMarker(coordinate)
    this.coordinateWithMarker.emit(coordinate)
  }


  ngOnChanges(changes: SimpleChanges): void {
    if(this.mapElement && 
        changes['coordinates'] && 
        this.coordinates
    )
      this.addMarker(this.coordinates)
  }

 
  
  
}