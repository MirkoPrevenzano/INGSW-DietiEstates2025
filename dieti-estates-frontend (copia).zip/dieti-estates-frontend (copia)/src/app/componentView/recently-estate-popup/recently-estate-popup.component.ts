import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-recently-estate-popup',
  imports: [CommonModule],
  templateUrl: './recently-estate-popup.component.html',
  styleUrl: './recently-estate-popup.component.scss'
})
export class RecentlyEstatePopupComponent {
  recentListings: any[] = []; 
  
  ngOnInit(): void {
    this.recentListings = [
      { title: 'Beautiful Apartment', description: 'A beautiful apartment in the city center.' },
      { title: 'Cozy House', description: 'A cozy house in the suburbs.' }
    ];
  }
}
