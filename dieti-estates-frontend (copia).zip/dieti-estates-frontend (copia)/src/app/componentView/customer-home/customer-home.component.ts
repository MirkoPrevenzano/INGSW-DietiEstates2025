import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { EstateType } from '../../model/estateType';
import { AutocompleteInputComponent } from '../autocomplete-input/autocomplete-input.component';
import { AddEstateComponent } from '../add-estate/add-estate.component';
import { FormFieldComponent } from '../form-field/form-field.component';
import { Form, FormControl, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MapPopupComponent } from '../map-popup/map-popup.component';
import { Coordinate } from '../../model/coordinate';

@Component({
  selector: 'app-customer-home',
  imports:[
    AutocompleteInputComponent, 
    FormFieldComponent
  ],
  templateUrl: './customer-home.component.html',
  styleUrls: ['./customer-home.component.scss']
})
export class CustomerHomeComponent implements AfterViewInit{
  
  @ViewChild('localityInput') localityInput!:AutocompleteInputComponent
  selectedType!: EstateType;
  selectedLocation: any;
  radius!: number
  coordinate!: Coordinate

  constructor(
    private readonly matDialog: MatDialog
  ){}

  formSelectType = new FormGroup(
    {
      estateType: new FormControl('')
    }
  )

  ngAfterViewInit(): void {
    this.localityInput.select.subscribe((locality)=>{
      if(locality)
        this.localityInput.setValue(locality.properties.formatted as string ?? '')
    })
  }
  
  onSelectedType(type: EstateType) {
    this.selectedType = type;
  }

  onLocationSelected(locality: any) {
    this.selectedLocation = locality;
    console.log(this.selectedLocation)
  }

  openMap() {
    const dialog =this.matDialog.open(MapPopupComponent,{
      minWidth:"50vw" ,
      minHeight:"24vh",
      disableClose: false,
      hasBackdrop: true,
      
    })

    dialog.afterClosed().subscribe(result=>{
      if(result){
        this.radius = result.radius
        this.coordinate = result.coordinate;

        this.submit()
      }
    })
  }

  submit(){
    //naviga nella pagina degli estate passando località oppure radius e coordinate
  }
}