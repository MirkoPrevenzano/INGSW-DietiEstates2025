import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-progress-bar',
  imports:[CommonModule],
  templateUrl: './progress-bar.component.html',
  styleUrls: ['./progress-bar.component.scss']
})
export class ProgressBarComponent {
  @Input() currentStep = 1;
  @Input() steps: string[] = []

  getProgressWidth() {
    return (this.currentStep / this.steps.length) * 100 + '%';
  }

  
}