import { Component, Input } from '@angular/core';
import { ImageSliderComponent } from '../../image-slider/image-slider.component';
import { EstateViewDescriptionComponent } from '../estate-view-description/estate-view-description.component';
import { EstateDescribe } from '../../../model/estateDescribe';

@Component({
  selector: 'app-estate-item-preview',
  imports: [
    ImageSliderComponent,
    EstateViewDescriptionComponent
  ],
  templateUrl: './estate-item-preview.component.html',
  styleUrl: './estate-item-preview.component.scss'
})
export class EstateItemPreviewComponent {

   exampleEstateDescribe: EstateDescribe = {
    title: 'Luxurious Family Home in the Heart of the City',
    description: `
      Welcome to this stunning luxurious family home located in the heart of the city. This exquisite property offers an unparalleled living experience with its elegant design, modern amenities, and prime location. 
  
      As you step inside, you are greeted by a grand foyer that leads to a spacious open-plan living area. The living room features high ceilings, large windows that flood the space with natural light, and a cozy fireplace, perfect for relaxing evenings with family and friends. The adjacent dining area is ideal for hosting dinner parties and gatherings, with ample space for a large dining table.
  
      The gourmet kitchen is a chef's dream, equipped with top-of-the-line stainless steel appliances, custom cabinetry, and a large center island with a breakfast bar. The kitchen seamlessly flows into a casual dining area and a family room, creating a perfect space for everyday living.
  
      The home boasts five generously sized bedrooms, each with its own en-suite bathroom. The master suite is a true retreat, featuring a spacious bedroom, a walk-in closet, and a luxurious bathroom with a soaking tub, a separate shower, and dual vanities. The additional bedrooms are equally impressive, offering comfort and privacy for family members and guests.
  
      Outside, the property offers a beautifully landscaped garden, a large terrace, and a private swimming pool. The outdoor space is perfect for entertaining, with plenty of room for outdoor dining, lounging, and enjoying the sunshine. The home also includes a three-car garage and additional off-street parking.
  
      This luxurious family home is located in a highly sought-after neighborhood, with easy access to top-rated schools, shopping, dining, and entertainment options. The property offers the perfect blend of city living and suburban tranquility, making it an ideal choice for discerning buyers.
  
      Don't miss the opportunity to make this exceptional property your new home. Schedule a private showing today and experience the luxury and elegance of this stunning family home.
    `,
    size: 450,
    roomsNumber: 5,
    floorNumber: 2,
    energyClass: 'A',
    parkingSpacesNumber: 3,
    condoFee: 200,
    furnitureCondition: 'New',
    estateCondition: 'Excellent'
  };
  @Input() estateDescribe:EstateDescribe = this.exampleEstateDescribe 
  @Input() photos: string[] = []

  showEstateDetail(){
    //this.router.navigate([`/estate/${this.realEstateId}`])
    console.log('Show estate detail')
  }

  sliderConfig = {
    slidesToShow: 1,
    slidesToScroll: 1,
    dots: true,
    infinite: true,
    autoplay: true,
    autoplaySpeed: 2000
  };
}
