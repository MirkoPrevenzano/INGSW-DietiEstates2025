import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { DescriptionEstatesFormComponent } from '../description-estates-form/description-estates-form.component';
import { EstatesFeaturesFormComponent } from '../estates-features-form/estates-features-form.component';
import { SelectPlaceComponent } from '../select-place/select-place.component';
import { CommonModule } from '@angular/common';
import { Address } from '../../../model/address';
import { EstateDescribe } from '../../../model/estateDescribe';
import { EstateFeatures } from '../../../model/estateFeatures';
import { Estate } from '../../../model/estate';
import { EstateType } from '../../../model/estateType';
import { ActivatedRoute } from '@angular/router';
import { EstateDataService } from '../../../_service/estate-data.service';
import { EstateFactoryService } from '../../../_service/estate-factory/estate-factory.service';
import { ProgressBarComponent } from '../../progress-bar/progress-bar.component';
import { Coordinate } from '../../../model/coordinate';
import { PoiService } from '../../../_service/map-service/poi-service/poi.service';
import { EstateLocationFeatures } from '../../../model/estateLocationFeatures';
import { Observable, switchMap } from 'rxjs';
import { UploadPhotoService } from '../../../_service/rest-backend/upload-photo/upload-photo.service';
import { ToastrService } from 'ngx-toastr';
import { EstateItemComponent } from '../../_estate-view/estate-item-detail/estate-item-detail.component';
import { EstateCreateService } from '../../../_service/rest-backend/estate-create/estate-create.service';

@Component({
  selector: 'app-create-estates',
  imports: [
    SelectPlaceComponent, 
    DescriptionEstatesFormComponent, 
    EstatesFeaturesFormComponent,
    CommonModule,
    ProgressBarComponent,
    EstateItemComponent
  ],
  templateUrl: './create-estates.component.html',
  styleUrl: './create-estates.component.scss'
})
export class CreateEstatesComponent implements OnInit, AfterViewInit{
  @ViewChild(DescriptionEstatesFormComponent) descriptionFormComponent!: DescriptionEstatesFormComponent;
  @ViewChild(EstatesFeaturesFormComponent) featuresFormComponent!: EstatesFeaturesFormComponent;
 


  address!: Address
  description!: EstateDescribe
  features!: EstateFeatures
  estate: Estate = {} as Estate
  additionalFields: any

  photos: string[] =[]
  estateLocation: EstateLocationFeatures = {
    isNearPublicTransport: false,
    isNearSchool: false,
    isNearPark: false
  };

  steps: string[] = [
    'Step 1: Address',
    'Step 2: Description',
    'Step 3: Services',
    'Step 4: Preview'
  ]

  constructor(
    private readonly route: ActivatedRoute,
    private readonly estateFactory: EstateFactoryService,
    private readonly estateDataService: EstateDataService,
    private readonly poiService: PoiService,
    private readonly uploadPhotosService: UploadPhotoService,
    private readonly toastrService: ToastrService,
    private readonly createEstateService:EstateCreateService

  ){}
  ngAfterViewInit(): void {
   //
  }

  onPhotosChanged(photos:string[]): void {
    this.photos = photos
  }

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.estate.type = params['type'] || 'For Sale';
    });
    this.address = this.estateDataService.getAddress()
    this.description = this.estateDataService.getDescription()
    this.additionalFields = this.estateDataService.getAdditionalFields()
    this.features = this.estateDataService.getFeatures()
    
  }
  currentStep = 1;

  nextStep() {
    if (this.currentStep < 4 ) {
      if(this.isCurrentStepValid()){
        this.currentStep++;
       
      }
      else
        console.log("Fill all fields")
    }
    if(this.currentStep==4)
      this.estate = this.createEstate()
  }

  previousStep() {
    if (this.currentStep > 1) {
      this.currentStep--;
    }
  }

  isStepCompleted(step: number) {
    return this.currentStep >= step;
  }

  onAddressOut(event: Address){
    this.address = event
    this.estateDataService.setAddress(this.address)

    this.estate.address=this.address
  }



  isCurrentStepValid(): boolean {
    switch (this.currentStep) {
      case 1:
        // Validazione per il primo step (Select Place)
        return !!this.address;
      case 2:
        // Validazione per il secondo step (Description)
        return this.descriptionFormComponent.isValid();
      case 3:
        // Validazione per il terzo step (Services)
        return this.featuresFormComponent.featuresForm.valid;
      case 4:
        return true;
        
      default:
        return false;
    }
  }

  onDescribeOut(event: any)
  {
    this.description = event.estate
    this.additionalFields= event.additionalFields
    this.estateDataService.setAdditionalFields(this.additionalFields)
    this.estateDataService.setDescription(this.description)

    this.estate.estateDescribe=this.description
  }

  onEstateFeatures(event: EstateFeatures){
    this.features = event
    this.estateDataService.setFeatures(this.features)
    this.estate.estateFeatures=this.features
  }

  /*vedere poi come concatenare le chiamate*/
  submit(){
    this.searchPoi({lat:this.address.latitude!, lon:this.address.longitude!}).subscribe((response:any)=>{
     this.estate=this.createEstate()
    })

    this.createEstateService.createEstate(this.estate).subscribe((response:any)=>{
      this.uploadPhotos(response.realEstateId)
    }) 
  }

  uploadPhotos(id: any) {
    this.uploadPhotosService.uploadPhotos(id, this.photos).subscribe((response:any)=>{
      console.log(response)
    })
  }

  createEstate(): Estate {
    this.estate.address = this.estateDataService.getAddress()
    this.estate.estateFeatures = this.features
    this.estate.estateDescribe = this.description
    this.estate.estateLocationFeatures= this.estateLocation
      
    return this.estateFactory.createEstate(
      this.estate,
      this.additionalFields
    );
  }


  /*da considerere service il codice nell'if e di separare return create estate*/
  searchPoi(coordinate:Coordinate): Observable<any>{
      const categories =['public_transport.bus', 'building.school','leisure.park']
      return this.poiService.searchPOI(coordinate, categories).pipe(
        switchMap((response: any) => {
          if (response?.features) {
            console.log(response)
            response.features.forEach((feature: any) => {
              if (feature.properties.categories.includes('public_transport.bus')) {
                this.estateLocation.isNearPublicTransport = true;
              }
              if (feature.properties.categories.includes('building.school')) {
                this.estateLocation.isNearSchool = true;
              }
              if (feature.properties.categories.includes('leisure.park')) {
                this.estateLocation.isNearPark = true;
              }
            });
          } else {
            console.error('Unexpected response format:', response);
          }
          return new Observable(observer => {
            observer.next(response);
            observer.complete();
          });
        })
      );
    }
}

