import { Component } from '@angular/core';

@Component({
  selector: 'app-estate-filters',
  imports: [],
  templateUrl: './estate-filters.component.html',
  styleUrl: './estate-filters.component.scss'
})
export class EstateFiltersComponent {

}
