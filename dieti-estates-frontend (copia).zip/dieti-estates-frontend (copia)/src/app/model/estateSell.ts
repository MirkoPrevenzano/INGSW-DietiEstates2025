import { Estate } from "./estate";

export interface EstateSell extends Estate{
    notaryDeedState: string,
    sellingPrice: number,
    type: 'For Sale'
}