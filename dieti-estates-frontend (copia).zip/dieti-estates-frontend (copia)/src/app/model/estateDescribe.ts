export interface EstateDescribe{
    title: string
    description: string,
    size: number,
    roomsNumber: number,
    floorNumber: number,
    energyClass: string,
    parkingSpacesNumber: number,
    condoFee: number,
    furnitureCondition: string,
    estateCondition: string,
}