export interface EstateLocationFeatures{
    isNearPark: boolean ,
    isNearPublicTransport: boolean,
    isNearSchool: boolean
}