export interface RegisterRequest{
    name: string,
    surname:string,
    username:string,
    password:string
}