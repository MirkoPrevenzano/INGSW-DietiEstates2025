export interface Coordinate{
    lat:number,
    lon:number
}