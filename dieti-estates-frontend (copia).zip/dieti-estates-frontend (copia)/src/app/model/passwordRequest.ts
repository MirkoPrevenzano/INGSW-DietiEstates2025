export interface PasswordRequest{
    oldPassword: string,
    newPassword: string,
}