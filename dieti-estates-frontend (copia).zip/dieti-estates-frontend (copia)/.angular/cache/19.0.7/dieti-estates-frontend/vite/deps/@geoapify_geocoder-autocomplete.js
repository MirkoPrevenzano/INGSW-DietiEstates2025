import {
  __spreadValues
} from "./chunk-3OV72XIM.js";

// node_modules/@geoapify/geocoder-autocomplete/dist/index.min.esm.js
var e = "countrycode";
var o = "rect";
var i = "circle";
var a = "proximity";
var t = "place";
var n = class _n {
  static isLatitude(e2) {
    return "" !== e2 && null !== e2 && isFinite(e2) && Math.abs(e2) <= 90;
  }
  static isLongitude(e2) {
    return "" !== e2 && null !== e2 && isFinite(e2) && Math.abs(e2) <= 180;
  }
  static isNotOpenStreetMapData(e2) {
    return "openstreetmap" !== e2.properties.datasource?.sourcename || !e2.properties.place_id;
  }
  static extendByNonVerifiedValues(e2, o2, i2) {
    o2.forEach((o3) => {
      i2.housenumber && e2.allowNonVerifiedHouseNumber && "match_by_street" === o3.properties.rank.match_type ? (this.addHouseNumberToFormatted(o3.properties, null, i2.housenumber), o3.properties.nonVerifiedParts = ["housenumber"]) : i2.street && i2.housenumber && e2.allowNonVerifiedStreet && ("match_by_city_or_disrict" === o3.properties.rank.match_type || "match_by_postcode" === o3.properties.rank.match_type) ? (this.addHouseNumberToFormatted(o3.properties, i2.street, i2.housenumber), o3.properties.nonVerifiedParts = ["housenumber", "street"]) : i2.street && e2.allowNonVerifiedStreet && ("match_by_city_or_disrict" === o3.properties.rank.match_type || "match_by_postcode" === o3.properties.rank.match_type) && (o3.properties.street = i2.street.replace(/(^\w|\s\w|[-]\w)/g, (e3) => e3.toUpperCase()), o3.properties.address_line1 = o3.properties.street, o3.properties.address_line2 = o3.properties.formatted, o3.properties.formatted = o3.properties.street + ", " + o3.properties.formatted, o3.properties.nonVerifiedParts = ["street"]);
    });
  }
  static addHouseNumberToFormatted(e2, o2, i2) {
    const a2 = {
      "{{{road}}} {{{house_number}}}": ["af", "ai", "al", "ao", "ar", "at", "aw", "ax", "ba", "be", "bg", "bi", "bo", "bq", "br", "bs", "bt", "bv", "bw", "cf", "ch", "cl", "cm", "co", "cr", "cu", "cv", "cw", "cy", "cz", "de", "dk", "do", "ec", "ee", "eh", "er", "et", "fi", "fo", "gd", "ge", "gl", "gq", "gr", "gt", "gw", "hn", "hr", "ht", "hu", "id", "il", "ir", "is", "jo", "ki", "km", "kp", "kw", "lc", "li", "lr", "lt", "lv", "ly", "me", "mk", "ml", "mn", "mo", "mx", "ni", "nl", "no", "np", "pa", "pe", "pl", "ps", "pt", "pw", "py", "qa", "ro", "rs", "ru", "sb", "sd", "se", "si", "sj", "sk", "so", "sr", "ss", "st", "sv", "sx", "sz", "td", "tj", "tl", "tr", "um", "uz", "uy", "vc", "ve", "vu", "ws"],
      "{{{house_number}}} {{{road}}}": ["ad", "ae", "ag", "am", "as", "au", "az", "bb", "bd", "bf", "bh", "bl", "bm", "bz", "ca", "cc", "ci", "ck", "cn", "cx", "dj", "dm", "dz", "eg", "fj", "fk", "fm", "fr", "ga", "gb", "gf", "gg", "gh", "gi", "gm", "gn", "gp", "gs", "gu", "gy", "hk", "hm", "ie", "im", "io", "iq", "je", "jm", "jp", "ke", "kh", "kn", "kr", "ky", "lb", "lk", "ls", "lu", "ma", "mc", "mf", "mh", "mg", "mm", "mp", "ms", "mt", "mq", "mv", "mw", "my", "na", "nc", "ne", "nf", "ng", "nr", "nu", "nz", "om", "pf", "pg", "ph", "pk", "pm", "pr", "re", "rw", "sa", "sc", "sg", "sh", "sl", "sn", "tc", "tf", "th", "tk", "tn", "to", "tt", "tv", "tw", "tz", "ug", "us", "vg", "vi", "wf", "yt", "za", "zm", "zw"],
      "{{{road}}}, {{{house_number}}}": ["by", "es", "it", "kg", "kz", "md", "mz", "sm", "sy", "ua", "va"],
      "{{{house_number}}}, {{{road}}}": ["bj", "bn", "cd", "cg", "in", "la", "mr", "mu", "tg", "tm", "vn", "ye"]
    }, t2 = Object.keys(a2).find((o3) => a2[o3].indexOf(e2.country_code) >= 0) || "{{{road}}} {{{house_number}}}";
    if (o2) {
      e2.street = o2.replace(/(^\w|\s\w|[-]\w)/g, (e3) => e3.toUpperCase()), e2.housenumber = i2;
      const a3 = t2.replace("{{{road}}}", e2.street).replace("{{{house_number}}}", i2);
      e2.address_line1 = a3, e2.address_line2 = e2.formatted, e2.formatted = a3 + ", " + e2.formatted;
    } else {
      e2.housenumber = i2;
      const o3 = t2.replace("{{{road}}}", e2.street).replace("{{{house_number}}}", i2);
      e2.address_line1 = e2.address_line1.replace(e2.street, o3), e2.formatted = e2.formatted.replace(e2.street, o3);
    }
  }
  static generatePlacesUrl(e2, o2, i2, a2) {
    let t2 = `${e2}?id=${o2}&apiKey=${i2}`;
    return a2.lang && (t2 += `&lang=${a2.lang}`), t2;
  }
  static needToFilterDataBySuggestionsFilter(e2, o2) {
    return e2 && e2.length && o2 && "function" == typeof o2;
  }
  static needToCalculateExtendByNonVerifiedValues(e2, o2) {
    return e2.features && e2.features.length && e2?.query?.parsed && (o2.allowNonVerifiedHouseNumber || o2.allowNonVerifiedStreet);
  }
  static generateUrl(d2, l2, r2, s2) {
    let c = `${l2}?text=${encodeURIComponent(d2)}&apiKey=${r2}`;
    s2.type && (c += `&type=${s2.type}`), s2.limit && (c += `&limit=${s2.limit}`), s2.lang && (c += `&lang=${s2.lang}`);
    const F = [], m = s2.filter[e], u = s2.filter[i], f = s2.filter[o], U = s2.filter[t];
    m && m.length && F.push(`countrycode:${m.join(",").toLowerCase()}`), u && _n.isLatitude(u.lat) && _n.isLongitude(u.lon) && u.radiusMeters > 0 && F.push(`circle:${u.lon},${u.lat},${u.radiusMeters}`), f && _n.isLatitude(f.lat1) && _n.isLongitude(f.lon1) && _n.isLatitude(f.lat2) && _n.isLongitude(f.lon2) && F.push(`rect:${f.lon1},${f.lat1},${f.lon2},${f.lat2}`), U && F.push(`place:${U}`), c += F.length ? `&filter=${F.join("|")}` : "";
    const g = [], h = s2.bias[e], C = s2.bias[i], p = s2.bias[o], E = s2.bias[a];
    return h && h.length && g.push(`countrycode:${h.join(",").toLowerCase()}`), C && _n.isLatitude(C.lat) && _n.isLongitude(C.lon) && C.radiusMeters > 0 && g.push(`circle:${C.lon},${C.lat},${C.radiusMeters}`), p && _n.isLatitude(p.lat1) && _n.isLongitude(p.lon1) && _n.isLatitude(p.lat2) && _n.isLongitude(p.lon2) && g.push(`rect:${p.lon1},${p.lat1},${p.lon2},${p.lat2}`), E && _n.isLatitude(E.lat) && _n.isLongitude(E.lon) && g.push(`proximity:${E.lon},${E.lat}`), c += g.length ? `&bias=${g.join("|")}` : "", c;
  }
  static returnIfFunction(e2) {
    return e2 && "function" == typeof e2 ? e2 : null;
  }
};
var d = [{
  code: "AD",
  emoji: "🇦🇩",
  unicode: "U+1F1E6 U+1F1E9",
  name: "Andorra",
  title: "flag for Andorra",
  dialCode: "+376"
}, {
  code: "AE",
  emoji: "🇦🇪",
  unicode: "U+1F1E6 U+1F1EA",
  name: "United Arab Emirates",
  title: "flag for United Arab Emirates",
  dialCode: "+971"
}, {
  code: "AF",
  emoji: "🇦🇫",
  unicode: "U+1F1E6 U+1F1EB",
  name: "Afghanistan",
  title: "flag for Afghanistan",
  dialCode: "+93"
}, {
  code: "AG",
  emoji: "🇦🇬",
  unicode: "U+1F1E6 U+1F1EC",
  name: "Antigua and Barbuda",
  title: "flag for Antigua and Barbuda",
  dialCode: "+1268"
}, {
  code: "AI",
  emoji: "🇦🇮",
  unicode: "U+1F1E6 U+1F1EE",
  name: "Anguilla",
  title: "flag for Anguilla",
  dialCode: "+1 264"
}, {
  code: "AL",
  emoji: "🇦🇱",
  unicode: "U+1F1E6 U+1F1F1",
  name: "Albania",
  title: "flag for Albania",
  dialCode: "+355"
}, {
  code: "AM",
  emoji: "🇦🇲",
  unicode: "U+1F1E6 U+1F1F2",
  name: "Armenia",
  title: "flag for Armenia",
  dialCode: "+374"
}, {
  code: "AO",
  emoji: "🇦🇴",
  unicode: "U+1F1E6 U+1F1F4",
  name: "Angola",
  title: "flag for Angola",
  dialCode: "+244"
}, {
  code: "AQ",
  emoji: "🇦🇶",
  unicode: "U+1F1E6 U+1F1F6",
  name: "Antarctica",
  title: "flag for Antarctica",
  dialCode: null
}, {
  code: "AR",
  emoji: "🇦🇷",
  unicode: "U+1F1E6 U+1F1F7",
  name: "Argentina",
  title: "flag for Argentina",
  dialCode: "+54"
}, {
  code: "AS",
  emoji: "🇦🇸",
  unicode: "U+1F1E6 U+1F1F8",
  name: "American Samoa",
  title: "flag for American Samoa",
  dialCode: "+1 684"
}, {
  code: "AT",
  emoji: "🇦🇹",
  unicode: "U+1F1E6 U+1F1F9",
  name: "Austria",
  title: "flag for Austria",
  dialCode: "+43"
}, {
  code: "AU",
  emoji: "🇦🇺",
  unicode: "U+1F1E6 U+1F1FA",
  name: "Australia",
  title: "flag for Australia",
  dialCode: "+61"
}, {
  code: "AW",
  emoji: "🇦🇼",
  unicode: "U+1F1E6 U+1F1FC",
  name: "Aruba",
  title: "flag for Aruba",
  dialCode: "+297"
}, {
  code: "AX",
  emoji: "🇦🇽",
  unicode: "U+1F1E6 U+1F1FD",
  name: "Åland Islands",
  title: "flag for Åland Islands",
  dialCode: ""
}, {
  code: "AZ",
  emoji: "🇦🇿",
  unicode: "U+1F1E6 U+1F1FF",
  name: "Azerbaijan",
  title: "flag for Azerbaijan",
  dialCode: "+994"
}, {
  code: "BA",
  emoji: "🇧🇦",
  unicode: "U+1F1E7 U+1F1E6",
  name: "Bosnia and Herzegovina",
  title: "flag for Bosnia and Herzegovina",
  dialCode: "+387"
}, {
  code: "BB",
  emoji: "🇧🇧",
  unicode: "U+1F1E7 U+1F1E7",
  name: "Barbados",
  title: "flag for Barbados",
  dialCode: "+1 246"
}, {
  code: "BD",
  emoji: "🇧🇩",
  unicode: "U+1F1E7 U+1F1E9",
  name: "Bangladesh",
  title: "flag for Bangladesh",
  dialCode: "+880"
}, {
  code: "BE",
  emoji: "🇧🇪",
  unicode: "U+1F1E7 U+1F1EA",
  name: "Belgium",
  title: "flag for Belgium",
  dialCode: "+32"
}, {
  code: "BF",
  emoji: "🇧🇫",
  unicode: "U+1F1E7 U+1F1EB",
  name: "Burkina Faso",
  title: "flag for Burkina Faso",
  dialCode: "+226"
}, {
  code: "BG",
  emoji: "🇧🇬",
  unicode: "U+1F1E7 U+1F1EC",
  name: "Bulgaria",
  title: "flag for Bulgaria",
  dialCode: "+359"
}, {
  code: "BH",
  emoji: "🇧🇭",
  unicode: "U+1F1E7 U+1F1ED",
  name: "Bahrain",
  title: "flag for Bahrain",
  dialCode: "+973"
}, {
  code: "BI",
  emoji: "🇧🇮",
  unicode: "U+1F1E7 U+1F1EE",
  name: "Burundi",
  title: "flag for Burundi",
  dialCode: "+257"
}, {
  code: "BJ",
  emoji: "🇧🇯",
  unicode: "U+1F1E7 U+1F1EF",
  name: "Benin",
  title: "flag for Benin",
  dialCode: "+229"
}, {
  code: "BL",
  emoji: "🇧🇱",
  unicode: "U+1F1E7 U+1F1F1",
  name: "Saint Barthélemy",
  title: "flag for Saint Barthélemy",
  dialCode: "+590"
}, {
  code: "BM",
  emoji: "🇧🇲",
  unicode: "U+1F1E7 U+1F1F2",
  name: "Bermuda",
  title: "flag for Bermuda",
  dialCode: "+1 441"
}, {
  code: "BN",
  emoji: "🇧🇳",
  unicode: "U+1F1E7 U+1F1F3",
  name: "Brunei Darussalam",
  title: "flag for Brunei Darussalam",
  dialCode: "+673"
}, {
  code: "BO",
  emoji: "🇧🇴",
  unicode: "U+1F1E7 U+1F1F4",
  name: "Bolivia",
  title: "flag for Bolivia",
  dialCode: "+591"
}, {
  code: "BQ",
  emoji: "🇧🇶",
  unicode: "U+1F1E7 U+1F1F6",
  name: "Bonaire, Sint Eustatius and Saba",
  title: "flag for Bonaire, Sint Eustatius and Saba"
}, {
  code: "BR",
  emoji: "🇧🇷",
  unicode: "U+1F1E7 U+1F1F7",
  name: "Brazil",
  title: "flag for Brazil",
  dialCode: "+55"
}, {
  code: "BS",
  emoji: "🇧🇸",
  unicode: "U+1F1E7 U+1F1F8",
  name: "Bahamas",
  title: "flag for Bahamas",
  dialCode: "+1 242"
}, {
  code: "BT",
  emoji: "🇧🇹",
  unicode: "U+1F1E7 U+1F1F9",
  name: "Bhutan",
  title: "flag for Bhutan",
  dialCode: "+975"
}, {
  code: "BV",
  emoji: "🇧🇻",
  unicode: "U+1F1E7 U+1F1FB",
  name: "Bouvet Island",
  title: "flag for Bouvet Island"
}, {
  code: "BW",
  emoji: "🇧🇼",
  unicode: "U+1F1E7 U+1F1FC",
  name: "Botswana",
  title: "flag for Botswana",
  dialCode: "+267"
}, {
  code: "BY",
  emoji: "🇧🇾",
  unicode: "U+1F1E7 U+1F1FE",
  name: "Belarus",
  title: "flag for Belarus",
  dialCode: "+375"
}, {
  code: "BZ",
  emoji: "🇧🇿",
  unicode: "U+1F1E7 U+1F1FF",
  name: "Belize",
  title: "flag for Belize",
  dialCode: "+501"
}, {
  code: "CA",
  emoji: "🇨🇦",
  unicode: "U+1F1E8 U+1F1E6",
  name: "Canada",
  title: "flag for Canada",
  dialCode: "+1"
}, {
  code: "CC",
  emoji: "🇨🇨",
  unicode: "U+1F1E8 U+1F1E8",
  name: "Cocos (Keeling) Islands",
  title: "flag for Cocos (Keeling) Islands",
  dialCode: "+61"
}, {
  code: "CD",
  emoji: "🇨🇩",
  unicode: "U+1F1E8 U+1F1E9",
  name: "Congo",
  title: "flag for Congo",
  dialCode: "+243"
}, {
  code: "CF",
  emoji: "🇨🇫",
  unicode: "U+1F1E8 U+1F1EB",
  name: "Central African Republic",
  title: "flag for Central African Republic",
  dialCode: "+236"
}, {
  code: "CG",
  emoji: "🇨🇬",
  unicode: "U+1F1E8 U+1F1EC",
  name: "Congo",
  title: "flag for Congo",
  dialCode: "+242"
}, {
  code: "CH",
  emoji: "🇨🇭",
  unicode: "U+1F1E8 U+1F1ED",
  name: "Switzerland",
  title: "flag for Switzerland",
  dialCode: "+41"
}, {
  code: "CI",
  emoji: "🇨🇮",
  unicode: "U+1F1E8 U+1F1EE",
  name: "Côte D'Ivoire",
  title: "flag for Côte D'Ivoire",
  dialCode: "+225"
}, {
  code: "CK",
  emoji: "🇨🇰",
  unicode: "U+1F1E8 U+1F1F0",
  name: "Cook Islands",
  title: "flag for Cook Islands",
  dialCode: "+682"
}, {
  code: "CL",
  emoji: "🇨🇱",
  unicode: "U+1F1E8 U+1F1F1",
  name: "Chile",
  title: "flag for Chile",
  dialCode: "+56"
}, {
  code: "CM",
  emoji: "🇨🇲",
  unicode: "U+1F1E8 U+1F1F2",
  name: "Cameroon",
  title: "flag for Cameroon",
  dialCode: "+237"
}, {
  code: "CN",
  emoji: "🇨🇳",
  unicode: "U+1F1E8 U+1F1F3",
  name: "China",
  title: "flag for China",
  dialCode: "+86"
}, {
  code: "CO",
  emoji: "🇨🇴",
  unicode: "U+1F1E8 U+1F1F4",
  name: "Colombia",
  title: "flag for Colombia",
  dialCode: "+57"
}, {
  code: "CR",
  emoji: "🇨🇷",
  unicode: "U+1F1E8 U+1F1F7",
  name: "Costa Rica",
  title: "flag for Costa Rica",
  dialCode: "+506"
}, {
  code: "CU",
  emoji: "🇨🇺",
  unicode: "U+1F1E8 U+1F1FA",
  name: "Cuba",
  title: "flag for Cuba",
  dialCode: "+53"
}, {
  code: "CV",
  emoji: "🇨🇻",
  unicode: "U+1F1E8 U+1F1FB",
  name: "Cape Verde",
  title: "flag for Cape Verde",
  dialCode: "+238"
}, {
  code: "CW",
  emoji: "🇨🇼",
  unicode: "U+1F1E8 U+1F1FC",
  name: "Curaçao",
  title: "flag for Curaçao"
}, {
  code: "CX",
  emoji: "🇨🇽",
  unicode: "U+1F1E8 U+1F1FD",
  name: "Christmas Island",
  title: "flag for Christmas Island",
  dialCode: "+61"
}, {
  code: "CY",
  emoji: "🇨🇾",
  unicode: "U+1F1E8 U+1F1FE",
  name: "Cyprus",
  title: "flag for Cyprus",
  dialCode: "+537"
}, {
  code: "CZ",
  emoji: "🇨🇿",
  unicode: "U+1F1E8 U+1F1FF",
  name: "Czech Republic",
  title: "flag for Czech Republic",
  dialCode: "+420"
}, {
  code: "DE",
  emoji: "🇩🇪",
  unicode: "U+1F1E9 U+1F1EA",
  name: "Germany",
  title: "flag for Germany",
  dialCode: "+49"
}, {
  code: "DJ",
  emoji: "🇩🇯",
  unicode: "U+1F1E9 U+1F1EF",
  name: "Djibouti",
  title: "flag for Djibouti",
  dialCode: "+253"
}, {
  code: "DK",
  emoji: "🇩🇰",
  unicode: "U+1F1E9 U+1F1F0",
  name: "Denmark",
  title: "flag for Denmark",
  dialCode: "+45"
}, {
  code: "DM",
  emoji: "🇩🇲",
  unicode: "U+1F1E9 U+1F1F2",
  name: "Dominica",
  title: "flag for Dominica",
  dialCode: "+1 767"
}, {
  code: "DO",
  emoji: "🇩🇴",
  unicode: "U+1F1E9 U+1F1F4",
  name: "Dominican Republic",
  title: "flag for Dominican Republic",
  dialCode: "+1 849"
}, {
  code: "DZ",
  emoji: "🇩🇿",
  unicode: "U+1F1E9 U+1F1FF",
  name: "Algeria",
  title: "flag for Algeria",
  dialCode: "+213"
}, {
  code: "EC",
  emoji: "🇪🇨",
  unicode: "U+1F1EA U+1F1E8",
  name: "Ecuador",
  title: "flag for Ecuador",
  dialCode: "+593"
}, {
  code: "EE",
  emoji: "🇪🇪",
  unicode: "U+1F1EA U+1F1EA",
  name: "Estonia",
  title: "flag for Estonia",
  dialCode: "+372"
}, {
  code: "EG",
  emoji: "🇪🇬",
  unicode: "U+1F1EA U+1F1EC",
  name: "Egypt",
  title: "flag for Egypt",
  dialCode: "+20"
}, {
  code: "EH",
  emoji: "🇪🇭",
  unicode: "U+1F1EA U+1F1ED",
  name: "Western Sahara",
  title: "flag for Western Sahara"
}, {
  code: "ER",
  emoji: "🇪🇷",
  unicode: "U+1F1EA U+1F1F7",
  name: "Eritrea",
  title: "flag for Eritrea",
  dialCode: "+291"
}, {
  code: "ES",
  emoji: "🇪🇸",
  unicode: "U+1F1EA U+1F1F8",
  name: "Spain",
  title: "flag for Spain",
  dialCode: "+34"
}, {
  code: "ET",
  emoji: "🇪🇹",
  unicode: "U+1F1EA U+1F1F9",
  name: "Ethiopia",
  title: "flag for Ethiopia",
  dialCode: "+251"
}, {
  code: "EU",
  emoji: "🇪🇺",
  unicode: "U+1F1EA U+1F1FA",
  name: "European Union",
  title: "flag for European Union"
}, {
  code: "FI",
  emoji: "🇫🇮",
  unicode: "U+1F1EB U+1F1EE",
  name: "Finland",
  title: "flag for Finland",
  dialCode: "+358"
}, {
  code: "FJ",
  emoji: "🇫🇯",
  unicode: "U+1F1EB U+1F1EF",
  name: "Fiji",
  title: "flag for Fiji",
  dialCode: "+679"
}, {
  code: "FK",
  emoji: "🇫🇰",
  unicode: "U+1F1EB U+1F1F0",
  name: "Falkland Islands (Malvinas)",
  title: "flag for Falkland Islands (Malvinas)",
  dialCode: "+500"
}, {
  code: "FM",
  emoji: "🇫🇲",
  unicode: "U+1F1EB U+1F1F2",
  name: "Micronesia",
  title: "flag for Micronesia",
  dialCode: "+691"
}, {
  code: "FO",
  emoji: "🇫🇴",
  unicode: "U+1F1EB U+1F1F4",
  name: "Faroe Islands",
  title: "flag for Faroe Islands",
  dialCode: "+298"
}, {
  code: "FR",
  emoji: "🇫🇷",
  unicode: "U+1F1EB U+1F1F7",
  name: "France",
  title: "flag for France",
  dialCode: "+33"
}, {
  code: "GA",
  emoji: "🇬🇦",
  unicode: "U+1F1EC U+1F1E6",
  name: "Gabon",
  title: "flag for Gabon",
  dialCode: "+241"
}, {
  code: "GB",
  emoji: "🇬🇧",
  unicode: "U+1F1EC U+1F1E7",
  name: "United Kingdom",
  title: "flag for United Kingdom",
  dialCode: "+44"
}, {
  code: "GD",
  emoji: "🇬🇩",
  unicode: "U+1F1EC U+1F1E9",
  name: "Grenada",
  title: "flag for Grenada",
  dialCode: "+1 473"
}, {
  code: "GE",
  emoji: "🇬🇪",
  unicode: "U+1F1EC U+1F1EA",
  name: "Georgia",
  title: "flag for Georgia",
  dialCode: "+995"
}, {
  code: "GF",
  emoji: "🇬🇫",
  unicode: "U+1F1EC U+1F1EB",
  name: "French Guiana",
  title: "flag for French Guiana",
  dialCode: "+594"
}, {
  code: "GG",
  emoji: "🇬🇬",
  unicode: "U+1F1EC U+1F1EC",
  name: "Guernsey",
  title: "flag for Guernsey",
  dialCode: "+44"
}, {
  code: "GH",
  emoji: "🇬🇭",
  unicode: "U+1F1EC U+1F1ED",
  name: "Ghana",
  title: "flag for Ghana",
  dialCode: "+233"
}, {
  code: "GI",
  emoji: "🇬🇮",
  unicode: "U+1F1EC U+1F1EE",
  name: "Gibraltar",
  title: "flag for Gibraltar",
  dialCode: "+350"
}, {
  code: "GL",
  emoji: "🇬🇱",
  unicode: "U+1F1EC U+1F1F1",
  name: "Greenland",
  title: "flag for Greenland",
  dialCode: "+299"
}, {
  code: "GM",
  emoji: "🇬🇲",
  unicode: "U+1F1EC U+1F1F2",
  name: "Gambia",
  title: "flag for Gambia",
  dialCode: "+220"
}, {
  code: "GN",
  emoji: "🇬🇳",
  unicode: "U+1F1EC U+1F1F3",
  name: "Guinea",
  title: "flag for Guinea",
  dialCode: "+224"
}, {
  code: "GP",
  emoji: "🇬🇵",
  unicode: "U+1F1EC U+1F1F5",
  name: "Guadeloupe",
  title: "flag for Guadeloupe",
  dialCode: "+590"
}, {
  code: "GQ",
  emoji: "🇬🇶",
  unicode: "U+1F1EC U+1F1F6",
  name: "Equatorial Guinea",
  title: "flag for Equatorial Guinea",
  dialCode: "+240"
}, {
  code: "GR",
  emoji: "🇬🇷",
  unicode: "U+1F1EC U+1F1F7",
  name: "Greece",
  title: "flag for Greece",
  dialCode: "+30"
}, {
  code: "GS",
  emoji: "🇬🇸",
  unicode: "U+1F1EC U+1F1F8",
  name: "South Georgia",
  title: "flag for South Georgia",
  dialCode: "+500"
}, {
  code: "GT",
  emoji: "🇬🇹",
  unicode: "U+1F1EC U+1F1F9",
  name: "Guatemala",
  title: "flag for Guatemala",
  dialCode: "+502"
}, {
  code: "GU",
  emoji: "🇬🇺",
  unicode: "U+1F1EC U+1F1FA",
  name: "Guam",
  title: "flag for Guam",
  dialCode: "+1 671"
}, {
  code: "GW",
  emoji: "🇬🇼",
  unicode: "U+1F1EC U+1F1FC",
  name: "Guinea-Bissau",
  title: "flag for Guinea-Bissau",
  dialCode: "+245"
}, {
  code: "GY",
  emoji: "🇬🇾",
  unicode: "U+1F1EC U+1F1FE",
  name: "Guyana",
  title: "flag for Guyana",
  dialCode: "+595"
}, {
  code: "HK",
  emoji: "🇭🇰",
  unicode: "U+1F1ED U+1F1F0",
  name: "Hong Kong",
  title: "flag for Hong Kong",
  dialCode: "+852"
}, {
  code: "HM",
  emoji: "🇭🇲",
  unicode: "U+1F1ED U+1F1F2",
  name: "Heard Island and Mcdonald Islands",
  title: "flag for Heard Island and Mcdonald Islands"
}, {
  code: "HN",
  emoji: "🇭🇳",
  unicode: "U+1F1ED U+1F1F3",
  name: "Honduras",
  title: "flag for Honduras",
  dialCode: "+504"
}, {
  code: "HR",
  emoji: "🇭🇷",
  unicode: "U+1F1ED U+1F1F7",
  name: "Croatia",
  title: "flag for Croatia",
  dialCode: "+385"
}, {
  code: "HT",
  emoji: "🇭🇹",
  unicode: "U+1F1ED U+1F1F9",
  name: "Haiti",
  title: "flag for Haiti",
  dialCode: "+509"
}, {
  code: "HU",
  emoji: "🇭🇺",
  unicode: "U+1F1ED U+1F1FA",
  name: "Hungary",
  title: "flag for Hungary",
  dialCode: "+36"
}, {
  code: "ID",
  emoji: "🇮🇩",
  unicode: "U+1F1EE U+1F1E9",
  name: "Indonesia",
  title: "flag for Indonesia",
  dialCode: "+62"
}, {
  code: "IE",
  emoji: "🇮🇪",
  unicode: "U+1F1EE U+1F1EA",
  name: "Ireland",
  title: "flag for Ireland",
  dialCode: "+353"
}, {
  code: "IL",
  emoji: "🇮🇱",
  unicode: "U+1F1EE U+1F1F1",
  name: "Israel",
  title: "flag for Israel",
  dialCode: "+972"
}, {
  code: "IM",
  emoji: "🇮🇲",
  unicode: "U+1F1EE U+1F1F2",
  name: "Isle of Man",
  title: "flag for Isle of Man",
  dialCode: "+44"
}, {
  code: "IN",
  emoji: "🇮🇳",
  unicode: "U+1F1EE U+1F1F3",
  name: "India",
  title: "flag for India",
  dialCode: "+91"
}, {
  code: "IO",
  emoji: "🇮🇴",
  unicode: "U+1F1EE U+1F1F4",
  name: "British Indian Ocean Territory",
  title: "flag for British Indian Ocean Territory",
  dialCode: "+246"
}, {
  code: "IQ",
  emoji: "🇮🇶",
  unicode: "U+1F1EE U+1F1F6",
  name: "Iraq",
  title: "flag for Iraq",
  dialCode: "+964"
}, {
  code: "IR",
  emoji: "🇮🇷",
  unicode: "U+1F1EE U+1F1F7",
  name: "Iran",
  title: "flag for Iran",
  dialCode: "+98"
}, {
  code: "IS",
  emoji: "🇮🇸",
  unicode: "U+1F1EE U+1F1F8",
  name: "Iceland",
  title: "flag for Iceland",
  dialCode: "+354"
}, {
  code: "IT",
  emoji: "🇮🇹",
  unicode: "U+1F1EE U+1F1F9",
  name: "Italy",
  title: "flag for Italy",
  dialCode: "+39"
}, {
  code: "JE",
  emoji: "🇯🇪",
  unicode: "U+1F1EF U+1F1EA",
  name: "Jersey",
  title: "flag for Jersey",
  dialCode: "+44"
}, {
  code: "JM",
  emoji: "🇯🇲",
  unicode: "U+1F1EF U+1F1F2",
  name: "Jamaica",
  title: "flag for Jamaica",
  dialCode: "+1 876"
}, {
  code: "JO",
  emoji: "🇯🇴",
  unicode: "U+1F1EF U+1F1F4",
  name: "Jordan",
  title: "flag for Jordan",
  dialCode: "+962"
}, {
  code: "JP",
  emoji: "🇯🇵",
  unicode: "U+1F1EF U+1F1F5",
  name: "Japan",
  title: "flag for Japan",
  dialCode: "+81"
}, {
  code: "KE",
  emoji: "🇰🇪",
  unicode: "U+1F1F0 U+1F1EA",
  name: "Kenya",
  title: "flag for Kenya",
  dialCode: "+254"
}, {
  code: "KG",
  emoji: "🇰🇬",
  unicode: "U+1F1F0 U+1F1EC",
  name: "Kyrgyzstan",
  title: "flag for Kyrgyzstan",
  dialCode: "+996"
}, {
  code: "KH",
  emoji: "🇰🇭",
  unicode: "U+1F1F0 U+1F1ED",
  name: "Cambodia",
  title: "flag for Cambodia",
  dialCode: "+855"
}, {
  code: "KI",
  emoji: "🇰🇮",
  unicode: "U+1F1F0 U+1F1EE",
  name: "Kiribati",
  title: "flag for Kiribati",
  dialCode: "+686"
}, {
  code: "KM",
  emoji: "🇰🇲",
  unicode: "U+1F1F0 U+1F1F2",
  name: "Comoros",
  title: "flag for Comoros",
  dialCode: "+269"
}, {
  code: "KN",
  emoji: "🇰🇳",
  unicode: "U+1F1F0 U+1F1F3",
  name: "Saint Kitts and Nevis",
  title: "flag for Saint Kitts and Nevis",
  dialCode: "+1 869"
}, {
  code: "KP",
  emoji: "🇰🇵",
  unicode: "U+1F1F0 U+1F1F5",
  name: "North Korea",
  title: "flag for North Korea",
  dialCode: "+850"
}, {
  code: "KR",
  emoji: "🇰🇷",
  unicode: "U+1F1F0 U+1F1F7",
  name: "South Korea",
  title: "flag for South Korea",
  dialCode: "+82"
}, {
  code: "KW",
  emoji: "🇰🇼",
  unicode: "U+1F1F0 U+1F1FC",
  name: "Kuwait",
  title: "flag for Kuwait",
  dialCode: "+965"
}, {
  code: "KY",
  emoji: "🇰🇾",
  unicode: "U+1F1F0 U+1F1FE",
  name: "Cayman Islands",
  title: "flag for Cayman Islands",
  dialCode: "+ 345"
}, {
  code: "KZ",
  emoji: "🇰🇿",
  unicode: "U+1F1F0 U+1F1FF",
  name: "Kazakhstan",
  title: "flag for Kazakhstan",
  dialCode: "+7 7"
}, {
  code: "LA",
  emoji: "🇱🇦",
  unicode: "U+1F1F1 U+1F1E6",
  name: "Lao People's Democratic Republic",
  title: "flag for Lao People's Democratic Republic",
  dialCode: "+856"
}, {
  code: "LB",
  emoji: "🇱🇧",
  unicode: "U+1F1F1 U+1F1E7",
  name: "Lebanon",
  title: "flag for Lebanon",
  dialCode: "+961"
}, {
  code: "LC",
  emoji: "🇱🇨",
  unicode: "U+1F1F1 U+1F1E8",
  name: "Saint Lucia",
  title: "flag for Saint Lucia",
  dialCode: "+1 758"
}, {
  code: "LI",
  emoji: "🇱🇮",
  unicode: "U+1F1F1 U+1F1EE",
  name: "Liechtenstein",
  title: "flag for Liechtenstein",
  dialCode: "+423"
}, {
  code: "LK",
  emoji: "🇱🇰",
  unicode: "U+1F1F1 U+1F1F0",
  name: "Sri Lanka",
  title: "flag for Sri Lanka",
  dialCode: "+94"
}, {
  code: "LR",
  emoji: "🇱🇷",
  unicode: "U+1F1F1 U+1F1F7",
  name: "Liberia",
  title: "flag for Liberia",
  dialCode: "+231"
}, {
  code: "LS",
  emoji: "🇱🇸",
  unicode: "U+1F1F1 U+1F1F8",
  name: "Lesotho",
  title: "flag for Lesotho",
  dialCode: "+266"
}, {
  code: "LT",
  emoji: "🇱🇹",
  unicode: "U+1F1F1 U+1F1F9",
  name: "Lithuania",
  title: "flag for Lithuania",
  dialCode: "+370"
}, {
  code: "LU",
  emoji: "🇱🇺",
  unicode: "U+1F1F1 U+1F1FA",
  name: "Luxembourg",
  title: "flag for Luxembourg",
  dialCode: "+352"
}, {
  code: "LV",
  emoji: "🇱🇻",
  unicode: "U+1F1F1 U+1F1FB",
  name: "Latvia",
  title: "flag for Latvia",
  dialCode: "+371"
}, {
  code: "LY",
  emoji: "🇱🇾",
  unicode: "U+1F1F1 U+1F1FE",
  name: "Libya",
  title: "flag for Libya",
  dialCode: "+218"
}, {
  code: "MA",
  emoji: "🇲🇦",
  unicode: "U+1F1F2 U+1F1E6",
  name: "Morocco",
  title: "flag for Morocco",
  dialCode: "+212"
}, {
  code: "MC",
  emoji: "🇲🇨",
  unicode: "U+1F1F2 U+1F1E8",
  name: "Monaco",
  title: "flag for Monaco",
  dialCode: "+377"
}, {
  code: "MD",
  emoji: "🇲🇩",
  unicode: "U+1F1F2 U+1F1E9",
  name: "Moldova",
  title: "flag for Moldova",
  dialCode: "+373"
}, {
  code: "ME",
  emoji: "🇲🇪",
  unicode: "U+1F1F2 U+1F1EA",
  name: "Montenegro",
  title: "flag for Montenegro",
  dialCode: "+382"
}, {
  code: "MF",
  emoji: "🇲🇫",
  unicode: "U+1F1F2 U+1F1EB",
  name: "Saint Martin (French Part)",
  title: "flag for Saint Martin (French Part)",
  dialCode: "+590"
}, {
  code: "MG",
  emoji: "🇲🇬",
  unicode: "U+1F1F2 U+1F1EC",
  name: "Madagascar",
  title: "flag for Madagascar",
  dialCode: "+261"
}, {
  code: "MH",
  emoji: "🇲🇭",
  unicode: "U+1F1F2 U+1F1ED",
  name: "Marshall Islands",
  title: "flag for Marshall Islands",
  dialCode: "+692"
}, {
  code: "MK",
  emoji: "🇲🇰",
  unicode: "U+1F1F2 U+1F1F0",
  name: "Macedonia",
  title: "flag for Macedonia",
  dialCode: "+389"
}, {
  code: "ML",
  emoji: "🇲🇱",
  unicode: "U+1F1F2 U+1F1F1",
  name: "Mali",
  title: "flag for Mali",
  dialCode: "+223"
}, {
  code: "MM",
  emoji: "🇲🇲",
  unicode: "U+1F1F2 U+1F1F2",
  name: "Myanmar",
  title: "flag for Myanmar",
  dialCode: "+95"
}, {
  code: "MN",
  emoji: "🇲🇳",
  unicode: "U+1F1F2 U+1F1F3",
  name: "Mongolia",
  title: "flag for Mongolia",
  dialCode: "+976"
}, {
  code: "MO",
  emoji: "🇲🇴",
  unicode: "U+1F1F2 U+1F1F4",
  name: "Macao",
  title: "flag for Macao",
  dialCode: "+853"
}, {
  code: "MP",
  emoji: "🇲🇵",
  unicode: "U+1F1F2 U+1F1F5",
  name: "Northern Mariana Islands",
  title: "flag for Northern Mariana Islands",
  dialCode: "+1 670"
}, {
  code: "MQ",
  emoji: "🇲🇶",
  unicode: "U+1F1F2 U+1F1F6",
  name: "Martinique",
  title: "flag for Martinique",
  dialCode: "+596"
}, {
  code: "MR",
  emoji: "🇲🇷",
  unicode: "U+1F1F2 U+1F1F7",
  name: "Mauritania",
  title: "flag for Mauritania",
  dialCode: "+222"
}, {
  code: "MS",
  emoji: "🇲🇸",
  unicode: "U+1F1F2 U+1F1F8",
  name: "Montserrat",
  title: "flag for Montserrat",
  dialCode: "+1664"
}, {
  code: "MT",
  emoji: "🇲🇹",
  unicode: "U+1F1F2 U+1F1F9",
  name: "Malta",
  title: "flag for Malta",
  dialCode: "+356"
}, {
  code: "MU",
  emoji: "🇲🇺",
  unicode: "U+1F1F2 U+1F1FA",
  name: "Mauritius",
  title: "flag for Mauritius",
  dialCode: "+230"
}, {
  code: "MV",
  emoji: "🇲🇻",
  unicode: "U+1F1F2 U+1F1FB",
  name: "Maldives",
  title: "flag for Maldives",
  dialCode: "+960"
}, {
  code: "MW",
  emoji: "🇲🇼",
  unicode: "U+1F1F2 U+1F1FC",
  name: "Malawi",
  title: "flag for Malawi",
  dialCode: "+265"
}, {
  code: "MX",
  emoji: "🇲🇽",
  unicode: "U+1F1F2 U+1F1FD",
  name: "Mexico",
  title: "flag for Mexico",
  dialCode: "+52"
}, {
  code: "MY",
  emoji: "🇲🇾",
  unicode: "U+1F1F2 U+1F1FE",
  name: "Malaysia",
  title: "flag for Malaysia",
  dialCode: "+60"
}, {
  code: "MZ",
  emoji: "🇲🇿",
  unicode: "U+1F1F2 U+1F1FF",
  name: "Mozambique",
  title: "flag for Mozambique",
  dialCode: "+258"
}, {
  code: "NA",
  emoji: "🇳🇦",
  unicode: "U+1F1F3 U+1F1E6",
  name: "Namibia",
  title: "flag for Namibia",
  dialCode: "+264"
}, {
  code: "NC",
  emoji: "🇳🇨",
  unicode: "U+1F1F3 U+1F1E8",
  name: "New Caledonia",
  title: "flag for New Caledonia",
  dialCode: "+687"
}, {
  code: "NE",
  emoji: "🇳🇪",
  unicode: "U+1F1F3 U+1F1EA",
  name: "Niger",
  title: "flag for Niger",
  dialCode: "+227"
}, {
  code: "NF",
  emoji: "🇳🇫",
  unicode: "U+1F1F3 U+1F1EB",
  name: "Norfolk Island",
  title: "flag for Norfolk Island",
  dialCode: "+672"
}, {
  code: "NG",
  emoji: "🇳🇬",
  unicode: "U+1F1F3 U+1F1EC",
  name: "Nigeria",
  title: "flag for Nigeria",
  dialCode: "+234"
}, {
  code: "NI",
  emoji: "🇳🇮",
  unicode: "U+1F1F3 U+1F1EE",
  name: "Nicaragua",
  title: "flag for Nicaragua",
  dialCode: "+505"
}, {
  code: "NL",
  emoji: "🇳🇱",
  unicode: "U+1F1F3 U+1F1F1",
  name: "Netherlands",
  title: "flag for Netherlands",
  dialCode: "+31"
}, {
  code: "NO",
  emoji: "🇳🇴",
  unicode: "U+1F1F3 U+1F1F4",
  name: "Norway",
  title: "flag for Norway",
  dialCode: "+47"
}, {
  code: "NP",
  emoji: "🇳🇵",
  unicode: "U+1F1F3 U+1F1F5",
  name: "Nepal",
  title: "flag for Nepal",
  dialCode: "+977"
}, {
  code: "NR",
  emoji: "🇳🇷",
  unicode: "U+1F1F3 U+1F1F7",
  name: "Nauru",
  title: "flag for Nauru",
  dialCode: "+674"
}, {
  code: "NU",
  emoji: "🇳🇺",
  unicode: "U+1F1F3 U+1F1FA",
  name: "Niue",
  title: "flag for Niue",
  dialCode: "+683"
}, {
  code: "NZ",
  emoji: "🇳🇿",
  unicode: "U+1F1F3 U+1F1FF",
  name: "New Zealand",
  title: "flag for New Zealand",
  dialCode: "+64"
}, {
  code: "OM",
  emoji: "🇴🇲",
  unicode: "U+1F1F4 U+1F1F2",
  name: "Oman",
  title: "flag for Oman",
  dialCode: "+968"
}, {
  code: "PA",
  emoji: "🇵🇦",
  unicode: "U+1F1F5 U+1F1E6",
  name: "Panama",
  title: "flag for Panama",
  dialCode: "+507"
}, {
  code: "PE",
  emoji: "🇵🇪",
  unicode: "U+1F1F5 U+1F1EA",
  name: "Peru",
  title: "flag for Peru",
  dialCode: "+51"
}, {
  code: "PF",
  emoji: "🇵🇫",
  unicode: "U+1F1F5 U+1F1EB",
  name: "French Polynesia",
  title: "flag for French Polynesia",
  dialCode: "+689"
}, {
  code: "PG",
  emoji: "🇵🇬",
  unicode: "U+1F1F5 U+1F1EC",
  name: "Papua New Guinea",
  title: "flag for Papua New Guinea",
  dialCode: "+675"
}, {
  code: "PH",
  emoji: "🇵🇭",
  unicode: "U+1F1F5 U+1F1ED",
  name: "Philippines",
  title: "flag for Philippines",
  dialCode: "+63"
}, {
  code: "PK",
  emoji: "🇵🇰",
  unicode: "U+1F1F5 U+1F1F0",
  name: "Pakistan",
  title: "flag for Pakistan",
  dialCode: "+92"
}, {
  code: "PL",
  emoji: "🇵🇱",
  unicode: "U+1F1F5 U+1F1F1",
  name: "Poland",
  title: "flag for Poland",
  dialCode: "+48"
}, {
  code: "PM",
  emoji: "🇵🇲",
  unicode: "U+1F1F5 U+1F1F2",
  name: "Saint Pierre and Miquelon",
  title: "flag for Saint Pierre and Miquelon",
  dialCode: "+508"
}, {
  code: "PN",
  emoji: "🇵🇳",
  unicode: "U+1F1F5 U+1F1F3",
  name: "Pitcairn",
  title: "flag for Pitcairn",
  dialCode: "+872"
}, {
  code: "PR",
  emoji: "🇵🇷",
  unicode: "U+1F1F5 U+1F1F7",
  name: "Puerto Rico",
  title: "flag for Puerto Rico",
  dialCode: "+1 939"
}, {
  code: "PS",
  emoji: "🇵🇸",
  unicode: "U+1F1F5 U+1F1F8",
  name: "Palestinian Territory",
  title: "flag for Palestinian Territory",
  dialCode: "+970"
}, {
  code: "PT",
  emoji: "🇵🇹",
  unicode: "U+1F1F5 U+1F1F9",
  name: "Portugal",
  title: "flag for Portugal",
  dialCode: "+351"
}, {
  code: "PW",
  emoji: "🇵🇼",
  unicode: "U+1F1F5 U+1F1FC",
  name: "Palau",
  title: "flag for Palau",
  dialCode: "+680"
}, {
  code: "PY",
  emoji: "🇵🇾",
  unicode: "U+1F1F5 U+1F1FE",
  name: "Paraguay",
  title: "flag for Paraguay",
  dialCode: "+595"
}, {
  code: "QA",
  emoji: "🇶🇦",
  unicode: "U+1F1F6 U+1F1E6",
  name: "Qatar",
  title: "flag for Qatar",
  dialCode: "+974"
}, {
  code: "RE",
  emoji: "🇷🇪",
  unicode: "U+1F1F7 U+1F1EA",
  name: "Réunion",
  title: "flag for Réunion",
  dialCode: "+262"
}, {
  code: "RO",
  emoji: "🇷🇴",
  unicode: "U+1F1F7 U+1F1F4",
  name: "Romania",
  title: "flag for Romania",
  dialCode: "+40"
}, {
  code: "RS",
  emoji: "🇷🇸",
  unicode: "U+1F1F7 U+1F1F8",
  name: "Serbia",
  title: "flag for Serbia",
  dialCode: "+381"
}, {
  code: "RU",
  emoji: "🇷🇺",
  unicode: "U+1F1F7 U+1F1FA",
  name: "Russia",
  title: "flag for Russia",
  dialCode: "+7"
}, {
  code: "RW",
  emoji: "🇷🇼",
  unicode: "U+1F1F7 U+1F1FC",
  name: "Rwanda",
  title: "flag for Rwanda",
  dialCode: "+250"
}, {
  code: "SA",
  emoji: "🇸🇦",
  unicode: "U+1F1F8 U+1F1E6",
  name: "Saudi Arabia",
  title: "flag for Saudi Arabia",
  dialCode: "+966"
}, {
  code: "SB",
  emoji: "🇸🇧",
  unicode: "U+1F1F8 U+1F1E7",
  name: "Solomon Islands",
  title: "flag for Solomon Islands",
  dialCode: "+677"
}, {
  code: "SC",
  emoji: "🇸🇨",
  unicode: "U+1F1F8 U+1F1E8",
  name: "Seychelles",
  title: "flag for Seychelles",
  dialCode: "+248"
}, {
  code: "SD",
  emoji: "🇸🇩",
  unicode: "U+1F1F8 U+1F1E9",
  name: "Sudan",
  title: "flag for Sudan",
  dialCode: "+249"
}, {
  code: "SE",
  emoji: "🇸🇪",
  unicode: "U+1F1F8 U+1F1EA",
  name: "Sweden",
  title: "flag for Sweden",
  dialCode: "+46"
}, {
  code: "SG",
  emoji: "🇸🇬",
  unicode: "U+1F1F8 U+1F1EC",
  name: "Singapore",
  title: "flag for Singapore",
  dialCode: "+65"
}, {
  code: "SH",
  emoji: "🇸🇭",
  unicode: "U+1F1F8 U+1F1ED",
  name: "Saint Helena, Ascension and Tristan Da Cunha",
  title: "flag for Saint Helena, Ascension and Tristan Da Cunha",
  dialCode: "+290"
}, {
  code: "SI",
  emoji: "🇸🇮",
  unicode: "U+1F1F8 U+1F1EE",
  name: "Slovenia",
  title: "flag for Slovenia",
  dialCode: "+386"
}, {
  code: "SJ",
  emoji: "🇸🇯",
  unicode: "U+1F1F8 U+1F1EF",
  name: "Svalbard and Jan Mayen",
  title: "flag for Svalbard and Jan Mayen",
  dialCode: "+47"
}, {
  code: "SK",
  emoji: "🇸🇰",
  unicode: "U+1F1F8 U+1F1F0",
  name: "Slovakia",
  title: "flag for Slovakia",
  dialCode: "+421"
}, {
  code: "SL",
  emoji: "🇸🇱",
  unicode: "U+1F1F8 U+1F1F1",
  name: "Sierra Leone",
  title: "flag for Sierra Leone",
  dialCode: "+232"
}, {
  code: "SM",
  emoji: "🇸🇲",
  unicode: "U+1F1F8 U+1F1F2",
  name: "San Marino",
  title: "flag for San Marino",
  dialCode: "+378"
}, {
  code: "SN",
  emoji: "🇸🇳",
  unicode: "U+1F1F8 U+1F1F3",
  name: "Senegal",
  title: "flag for Senegal",
  dialCode: "+221"
}, {
  code: "SO",
  emoji: "🇸🇴",
  unicode: "U+1F1F8 U+1F1F4",
  name: "Somalia",
  title: "flag for Somalia",
  dialCode: "+252"
}, {
  code: "SR",
  emoji: "🇸🇷",
  unicode: "U+1F1F8 U+1F1F7",
  name: "Suriname",
  title: "flag for Suriname",
  dialCode: "+597"
}, {
  code: "SS",
  emoji: "🇸🇸",
  unicode: "U+1F1F8 U+1F1F8",
  name: "South Sudan",
  title: "flag for South Sudan"
}, {
  code: "ST",
  emoji: "🇸🇹",
  unicode: "U+1F1F8 U+1F1F9",
  name: "Sao Tome and Principe",
  title: "flag for Sao Tome and Principe",
  dialCode: "+239"
}, {
  code: "SV",
  emoji: "🇸🇻",
  unicode: "U+1F1F8 U+1F1FB",
  name: "El Salvador",
  title: "flag for El Salvador",
  dialCode: "+503"
}, {
  code: "SX",
  emoji: "🇸🇽",
  unicode: "U+1F1F8 U+1F1FD",
  name: "Sint Maarten (Dutch Part)",
  title: "flag for Sint Maarten (Dutch Part)"
}, {
  code: "SY",
  emoji: "🇸🇾",
  unicode: "U+1F1F8 U+1F1FE",
  name: "Syrian Arab Republic",
  title: "flag for Syrian Arab Republic",
  dialCode: "+963"
}, {
  code: "SZ",
  emoji: "🇸🇿",
  unicode: "U+1F1F8 U+1F1FF",
  name: "Swaziland",
  title: "flag for Swaziland",
  dialCode: "+268"
}, {
  code: "TC",
  emoji: "🇹🇨",
  unicode: "U+1F1F9 U+1F1E8",
  name: "Turks and Caicos Islands",
  title: "flag for Turks and Caicos Islands",
  dialCode: "+1 649"
}, {
  code: "TD",
  emoji: "🇹🇩",
  unicode: "U+1F1F9 U+1F1E9",
  name: "Chad",
  title: "flag for Chad",
  dialCode: "+235"
}, {
  code: "TF",
  emoji: "🇹🇫",
  unicode: "U+1F1F9 U+1F1EB",
  name: "French Southern Territories",
  title: "flag for French Southern Territories"
}, {
  code: "TG",
  emoji: "🇹🇬",
  unicode: "U+1F1F9 U+1F1EC",
  name: "Togo",
  title: "flag for Togo",
  dialCode: "+228"
}, {
  code: "TH",
  emoji: "🇹🇭",
  unicode: "U+1F1F9 U+1F1ED",
  name: "Thailand",
  title: "flag for Thailand",
  dialCode: "+66"
}, {
  code: "TJ",
  emoji: "🇹🇯",
  unicode: "U+1F1F9 U+1F1EF",
  name: "Tajikistan",
  title: "flag for Tajikistan",
  dialCode: "+992"
}, {
  code: "TK",
  emoji: "🇹🇰",
  unicode: "U+1F1F9 U+1F1F0",
  name: "Tokelau",
  title: "flag for Tokelau",
  dialCode: "+690"
}, {
  code: "TL",
  emoji: "🇹🇱",
  unicode: "U+1F1F9 U+1F1F1",
  name: "Timor-Leste",
  title: "flag for Timor-Leste",
  dialCode: "+670"
}, {
  code: "TM",
  emoji: "🇹🇲",
  unicode: "U+1F1F9 U+1F1F2",
  name: "Turkmenistan",
  title: "flag for Turkmenistan",
  dialCode: "+993"
}, {
  code: "TN",
  emoji: "🇹🇳",
  unicode: "U+1F1F9 U+1F1F3",
  name: "Tunisia",
  title: "flag for Tunisia",
  dialCode: "+216"
}, {
  code: "TO",
  emoji: "🇹🇴",
  unicode: "U+1F1F9 U+1F1F4",
  name: "Tonga",
  title: "flag for Tonga",
  dialCode: "+676"
}, {
  code: "TR",
  emoji: "🇹🇷",
  unicode: "U+1F1F9 U+1F1F7",
  name: "Turkey",
  title: "flag for Turkey",
  dialCode: "+90"
}, {
  code: "TT",
  emoji: "🇹🇹",
  unicode: "U+1F1F9 U+1F1F9",
  name: "Trinidad and Tobago",
  title: "flag for Trinidad and Tobago",
  dialCode: "+1 868"
}, {
  code: "TV",
  emoji: "🇹🇻",
  unicode: "U+1F1F9 U+1F1FB",
  name: "Tuvalu",
  title: "flag for Tuvalu",
  dialCode: "+688"
}, {
  code: "TW",
  emoji: "🇹🇼",
  unicode: "U+1F1F9 U+1F1FC",
  name: "Taiwan",
  title: "flag for Taiwan",
  dialCode: "+886"
}, {
  code: "TZ",
  emoji: "🇹🇿",
  unicode: "U+1F1F9 U+1F1FF",
  name: "Tanzania",
  title: "flag for Tanzania",
  dialCode: "+255"
}, {
  code: "UA",
  emoji: "🇺🇦",
  unicode: "U+1F1FA U+1F1E6",
  name: "Ukraine",
  title: "flag for Ukraine",
  dialCode: "+380"
}, {
  code: "UG",
  emoji: "🇺🇬",
  unicode: "U+1F1FA U+1F1EC",
  name: "Uganda",
  title: "flag for Uganda",
  dialCode: "+256"
}, {
  code: "UM",
  emoji: "🇺🇲",
  unicode: "U+1F1FA U+1F1F2",
  name: "United States Minor Outlying Islands",
  title: "flag for United States Minor Outlying Islands"
}, {
  code: "US",
  emoji: "🇺🇸",
  unicode: "U+1F1FA U+1F1F8",
  name: "United States",
  title: "flag for United States",
  dialCode: "+1"
}, {
  code: "UY",
  emoji: "🇺🇾",
  unicode: "U+1F1FA U+1F1FE",
  name: "Uruguay",
  title: "flag for Uruguay",
  dialCode: "+598"
}, {
  code: "UZ",
  emoji: "🇺🇿",
  unicode: "U+1F1FA U+1F1FF",
  name: "Uzbekistan",
  title: "flag for Uzbekistan",
  dialCode: "+998"
}, {
  code: "VA",
  emoji: "🇻🇦",
  unicode: "U+1F1FB U+1F1E6",
  name: "Vatican City",
  title: "flag for Vatican City",
  dialCode: "+379"
}, {
  code: "VC",
  emoji: "🇻🇨",
  unicode: "U+1F1FB U+1F1E8",
  name: "Saint Vincent and The Grenadines",
  title: "flag for Saint Vincent and The Grenadines",
  dialCode: "+1 784"
}, {
  code: "VE",
  emoji: "🇻🇪",
  unicode: "U+1F1FB U+1F1EA",
  name: "Venezuela",
  title: "flag for Venezuela",
  dialCode: "+58"
}, {
  code: "VG",
  emoji: "🇻🇬",
  unicode: "U+1F1FB U+1F1EC",
  name: "Virgin Islands, British",
  title: "flag for Virgin Islands, British",
  dialCode: "+1 284"
}, {
  code: "VI",
  emoji: "🇻🇮",
  unicode: "U+1F1FB U+1F1EE",
  name: "Virgin Islands, U.S.",
  title: "flag for Virgin Islands, U.S.",
  dialCode: "+1 340"
}, {
  code: "VN",
  emoji: "🇻🇳",
  unicode: "U+1F1FB U+1F1F3",
  name: "Viet Nam",
  title: "flag for Viet Nam",
  dialCode: "+84"
}, {
  code: "VU",
  emoji: "🇻🇺",
  unicode: "U+1F1FB U+1F1FA",
  name: "Vanuatu",
  title: "flag for Vanuatu",
  dialCode: "+678"
}, {
  code: "WF",
  emoji: "🇼🇫",
  unicode: "U+1F1FC U+1F1EB",
  name: "Wallis and Futuna",
  title: "flag for Wallis and Futuna",
  dialCode: "+681"
}, {
  code: "WS",
  emoji: "🇼🇸",
  unicode: "U+1F1FC U+1F1F8",
  name: "Samoa",
  title: "flag for Samoa",
  dialCode: "+685"
}, {
  code: "XK",
  emoji: "🇽🇰",
  unicode: "U+1F1FD U+1F1F0",
  name: "Kosovo",
  title: "flag for Kosovo",
  dialCode: "+383"
}, {
  code: "YE",
  emoji: "🇾🇪",
  unicode: "U+1F1FE U+1F1EA",
  name: "Yemen",
  title: "flag for Yemen",
  dialCode: "+967"
}, {
  code: "YT",
  emoji: "🇾🇹",
  unicode: "U+1F1FE U+1F1F9",
  name: "Mayotte",
  title: "flag for Mayotte",
  dialCode: "+262"
}, {
  code: "ZA",
  emoji: "🇿🇦",
  unicode: "U+1F1FF U+1F1E6",
  name: "South Africa",
  title: "flag for South Africa",
  dialCode: "+27"
}, {
  code: "ZM",
  emoji: "🇿🇲",
  unicode: "U+1F1FF U+1F1F2",
  name: "Zambia",
  title: "flag for Zambia",
  dialCode: "+260"
}, {
  code: "ZW",
  emoji: "🇿🇼",
  unicode: "U+1F1FF U+1F1FC",
  name: "Zimbabwe",
  title: "flag for Zimbabwe",
  dialCode: "+263"
}];
var l = class _l {
  static createInputElement(e2, o2, i2) {
    e2.classList.add("geoapify-autocomplete-input"), e2.setAttribute("type", "text"), e2.setAttribute("placeholder", o2.placeholder || "Enter an address here"), i2.appendChild(e2);
  }
  static addFeatureIcon(e2, o2, i2) {
    const a2 = {
      unknown: "map-marker",
      amenity: "map-marker",
      building: "map-marker",
      street: "road",
      suburb: "city",
      district: "city",
      postcode: "city",
      city: "city",
      county: "city",
      state: "city"
    }, t2 = d.find((e3) => i2 && e3.code.toLowerCase() === i2.toLowerCase());
    if ("country" === o2 && t2) {
      e2.classList.add("emoji");
      const o3 = document.createElement("span");
      o3.innerText = t2.emoji, e2.appendChild(o3);
    } else this.addIcon(e2, a2[o2] ? a2[o2] : "map-marker");
  }
  static addIcon(e2, o2) {
    const i2 = {
      close: {
        path: "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z",
        viewbox: "0 0 24 24"
      },
      "map-marker": {
        path: "M172.268 501.67C26.97 291.031 0 269.413 0 192 0 85.961 85.961 0 192 0s192 85.961 192 192c0 77.413-26.97 99.031-172.268 309.67-9.535 13.774-29.93 13.773-39.464 0zM192 272c44.183 0 80-35.817 80-80s-35.817-80-80-80-80 35.817-80 80 35.817 80 80 80z",
        viewbox: "0 0 384 512"
      },
      road: {
        path: "M573.19 402.67l-139.79-320C428.43 71.29 417.6 64 405.68 64h-97.59l2.45 23.16c.5 4.72-3.21 8.84-7.96 8.84h-29.16c-4.75 0-8.46-4.12-7.96-8.84L267.91 64h-97.59c-11.93 0-22.76 7.29-27.73 18.67L2.8 402.67C-6.45 423.86 8.31 448 30.54 448h196.84l10.31-97.68c.86-8.14 7.72-14.32 15.91-14.32h68.8c8.19 0 15.05 6.18 15.91 14.32L348.62 448h196.84c22.23 0 36.99-24.14 27.73-45.33zM260.4 135.16a8 8 0 0 1 7.96-7.16h39.29c4.09 0 7.53 3.09 7.96 7.16l4.6 43.58c.75 7.09-4.81 13.26-11.93 13.26h-40.54c-7.13 0-12.68-6.17-11.93-13.26l4.59-43.58zM315.64 304h-55.29c-9.5 0-16.91-8.23-15.91-17.68l5.07-48c.86-8.14 7.72-14.32 15.91-14.32h45.15c8.19 0 15.05 6.18 15.91 14.32l5.07 48c1 9.45-6.41 17.68-15.91 17.68z",
        viewbox: "0 0 576 512"
      },
      city: {
        path: "M616 192H480V24c0-13.26-10.74-24-24-24H312c-13.26 0-24 10.74-24 24v72h-64V16c0-8.84-7.16-16-16-16h-16c-8.84 0-16 7.16-16 16v80h-64V16c0-8.84-7.16-16-16-16H80c-8.84 0-16 7.16-16 16v80H24c-13.26 0-24 10.74-24 24v360c0 17.67 14.33 32 32 32h576c17.67 0 32-14.33 32-32V216c0-13.26-10.75-24-24-24zM128 404c0 6.63-5.37 12-12 12H76c-6.63 0-12-5.37-12-12v-40c0-6.63 5.37-12 12-12h40c6.63 0 12 5.37 12 12v40zm0-96c0 6.63-5.37 12-12 12H76c-6.63 0-12-5.37-12-12v-40c0-6.63 5.37-12 12-12h40c6.63 0 12 5.37 12 12v40zm0-96c0 6.63-5.37 12-12 12H76c-6.63 0-12-5.37-12-12v-40c0-6.63 5.37-12 12-12h40c6.63 0 12 5.37 12 12v40zm128 192c0 6.63-5.37 12-12 12h-40c-6.63 0-12-5.37-12-12v-40c0-6.63 5.37-12 12-12h40c6.63 0 12 5.37 12 12v40zm0-96c0 6.63-5.37 12-12 12h-40c-6.63 0-12-5.37-12-12v-40c0-6.63 5.37-12 12-12h40c6.63 0 12 5.37 12 12v40zm0-96c0 6.63-5.37 12-12 12h-40c-6.63 0-12-5.37-12-12v-40c0-6.63 5.37-12 12-12h40c6.63 0 12 5.37 12 12v40zm160 96c0 6.63-5.37 12-12 12h-40c-6.63 0-12-5.37-12-12v-40c0-6.63 5.37-12 12-12h40c6.63 0 12 5.37 12 12v40zm0-96c0 6.63-5.37 12-12 12h-40c-6.63 0-12-5.37-12-12v-40c0-6.63 5.37-12 12-12h40c6.63 0 12 5.37 12 12v40zm0-96c0 6.63-5.37 12-12 12h-40c-6.63 0-12-5.37-12-12V76c0-6.63 5.37-12 12-12h40c6.63 0 12 5.37 12 12v40zm160 288c0 6.63-5.37 12-12 12h-40c-6.63 0-12-5.37-12-12v-40c0-6.63 5.37-12 12-12h40c6.63 0 12 5.37 12 12v40zm0-96c0 6.63-5.37 12-12 12h-40c-6.63 0-12-5.37-12-12v-40c0-6.63 5.37-12 12-12h40c6.63 0 12 5.37 12 12v40z",
        viewbox: "0 0 640 512"
      }
    };
    var a2 = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    a2.setAttribute("viewBox", i2[o2].viewbox), a2.setAttribute("height", "24");
    var t2 = document.createElementNS("http://www.w3.org/2000/svg", "path");
    t2.setAttribute("d", i2[o2].path), t2.setAttribute("fill", "currentColor"), a2.appendChild(t2), e2.appendChild(a2);
  }
  static getStyledAddressSingleValue(e2, o2) {
    let i2 = e2;
    const a2 = (i2 || "").toLowerCase().indexOf(o2.toLowerCase());
    return a2 >= 0 && (i2 = i2.substring(0, a2) + `<strong>${i2.substring(a2, a2 + o2.length)}</strong>` + i2.substring(a2 + o2.length)), `<span class="main-part">${i2}</span>`;
  }
  static getStyledAddress(e2, o2) {
    let i2, a2;
    const t2 = e2.formatted.split(",").map((e3) => e3.trim());
    if (e2.name) i2 = t2[0], a2 = t2.slice(1).join(", ");
    else {
      const e3 = Math.min(2, Math.max(t2.length - 2, 1));
      i2 = t2.slice(0, e3).join(", "), a2 = t2.slice(e3).join(", ");
    }
    if (e2.nonVerifiedParts && e2.nonVerifiedParts.length) e2.nonVerifiedParts.forEach((o3) => {
      i2 = i2.replace(e2[o3], `<span class="non-verified">${e2[o3]}</span>`);
    });
    else {
      const e3 = i2.toLowerCase().indexOf(o2.toLowerCase());
      e3 >= 0 && (i2 = i2.substring(0, e3) + `<strong>${i2.substring(e3, e3 + o2.length)}</strong>` + i2.substring(e3 + o2.length));
    }
    return `<span class="main-part">${i2}</span><span class="secondary-part">${a2}</span>`;
  }
  static addDropdownIcon(e2, o2) {
    const i2 = document.createElement("span");
    i2.classList.add("icon"), _l.addFeatureIcon(i2, e2.properties.result_type, e2.properties.country_code), o2.appendChild(i2);
  }
  static addActiveClassToDropdownItem(e2, o2) {
    for (var i2 = 0; i2 < e2.length; i2++) e2[i2].classList.remove("active");
    e2[o2].classList.add("active");
  }
  static createDropdownItemText() {
    const e2 = document.createElement("span");
    return e2.classList.add("address"), e2;
  }
  static createDropdownItem() {
    const e2 = document.createElement("div");
    return e2.classList.add("geoapify-autocomplete-item"), e2;
  }
};
var r = class {
  changeCallbacks = [];
  suggestionsChangeCallbacks = [];
  inputCallbacks = [];
  openCallbacks = [];
  closeCallbacks = [];
  addCallback(e2, o2) {
    let i2 = this.getCallbacksByOperation(e2);
    i2 && i2.indexOf(o2) < 0 && i2.push(o2);
  }
  removeCallback(e2, o2) {
    let i2 = this.getCallbacksByOperation(e2);
    i2 && (i2.indexOf(o2) >= 0 ? (i2.splice(i2.indexOf(o2), 1), this.setCallbacksByOperation(e2, i2)) : o2 || this.setCallbacksByOperation(e2, []));
  }
  notifyInputChange(e2) {
    this.inputCallbacks.forEach((o2) => o2(e2));
  }
  notifyChange(e2) {
    this.changeCallbacks.forEach((o2) => o2(e2));
  }
  notifySuggestions(e2) {
    this.suggestionsChangeCallbacks.forEach((o2) => o2(e2));
  }
  notifyOpened() {
    this.openCallbacks.forEach((e2) => e2(true));
  }
  notifyClosed() {
    this.closeCallbacks.forEach((e2) => e2(false));
  }
  getCallbacksByOperation(e2) {
    let o2 = null;
    switch (e2) {
      case "select":
        o2 = this.changeCallbacks;
        break;
      case "suggestions":
        o2 = this.suggestionsChangeCallbacks;
        break;
      case "input":
        o2 = this.inputCallbacks;
        break;
      case "close":
        o2 = this.closeCallbacks;
        break;
      case "open":
        o2 = this.openCallbacks;
    }
    return o2;
  }
  setCallbacksByOperation(e2, o2) {
    switch (e2) {
      case "select":
        this.changeCallbacks = o2;
        break;
      case "suggestions":
        this.suggestionsChangeCallbacks = o2;
        break;
      case "input":
        this.inputCallbacks = o2;
        break;
      case "close":
        this.closeCallbacks = o2;
        break;
      case "open":
        this.openCallbacks = o2;
    }
  }
};
var s = class {
  container;
  apiKey;
  inputElement;
  inputClearButton;
  autocompleteItemsElement = null;
  focusedItemIndex;
  currentItems;
  currentPromiseReject;
  currentPlaceDetailsPromiseReject;
  currentTimeout;
  callbacks = new r();
  preprocessHook;
  postprocessHook;
  suggestionsFilter;
  sendGeocoderRequestAlt;
  sendPlaceDetailsRequestAlt;
  geocoderUrl = "https://api.geoapify.com/v1/geocode/autocomplete";
  placeDetailsUrl = "https://api.geoapify.com/v2/place-details";
  options = {
    limit: 5,
    debounceDelay: 100
  };
  constructor(e2, o2, i2) {
    this.container = e2, this.apiKey = o2, this.constructOptions(i2), this.inputElement = document.createElement("input"), l.createInputElement(this.inputElement, this.options, this.container), this.addClearButton(), this.addEventListeners();
  }
  setGeocoderUrl(e2) {
    this.geocoderUrl = e2;
  }
  setPlaceDetailsUrl(e2) {
    this.placeDetailsUrl = e2;
  }
  setType(e2) {
    this.options.type = e2;
  }
  setLang(e2) {
    this.options.lang = e2;
  }
  setAddDetails(e2) {
    this.options.addDetails = e2;
  }
  setSkipIcons(e2) {
    this.options.skipIcons = e2;
  }
  setAllowNonVerifiedHouseNumber(e2) {
    this.options.allowNonVerifiedHouseNumber = e2;
  }
  setAllowNonVerifiedStreet(e2) {
    this.options.allowNonVerifiedStreet = e2;
  }
  setCountryCodes(e2) {
    console.warn("WARNING! Obsolete function called. Function setCountryCodes() has been deprecated, please use the new addFilterByCountry() function instead!"), this.options.countryCodes = e2;
  }
  setPosition(e2) {
    console.warn("WARNING! Obsolete function called. Function setPosition() has been deprecated, please use the new addBiasByProximity() function instead!"), this.options.position = e2;
  }
  setLimit(e2) {
    this.options.limit = e2;
  }
  setValue(e2) {
    e2 ? this.inputClearButton.classList.add("visible") : this.inputClearButton.classList.remove("visible"), this.inputElement.value = e2;
  }
  getValue() {
    return this.inputElement.value;
  }
  addFilterByCountry(o2) {
    this.options.filter[e] = o2;
  }
  addFilterByCircle(e2) {
    this.options.filter[i] = e2;
  }
  addFilterByRect(e2) {
    this.options.filter[o] = e2;
  }
  addFilterByPlace(e2) {
    this.options.filter[t] = e2;
  }
  clearFilters() {
    this.options.filter = {};
  }
  addBiasByCountry(o2) {
    this.options.bias[e] = o2;
  }
  addBiasByCircle(e2) {
    this.options.bias[i] = e2;
  }
  addBiasByRect(e2) {
    this.options.bias[o] = e2;
  }
  addBiasByProximity(e2) {
    this.options.bias[a] = e2;
  }
  clearBias() {
    this.options.bias = {};
  }
  on(e2, o2) {
    this.callbacks.addCallback(e2, o2);
  }
  off(e2, o2) {
    this.callbacks.removeCallback(e2, o2);
  }
  once(e2, o2) {
    this.on(e2, o2);
    const i2 = this, a2 = () => {
      i2.off(e2, o2), i2.off(e2, a2);
    };
    this.on(e2, a2);
  }
  setSuggestionsFilter(e2) {
    this.suggestionsFilter = n.returnIfFunction(e2);
  }
  setPreprocessHook(e2) {
    this.preprocessHook = n.returnIfFunction(e2);
  }
  setPostprocessHook(e2) {
    this.postprocessHook = n.returnIfFunction(e2);
  }
  setSendGeocoderRequestFunc(e2) {
    this.sendGeocoderRequestAlt = n.returnIfFunction(e2);
  }
  setSendPlaceDetailsRequestFunc(e2) {
    this.sendPlaceDetailsRequestAlt = n.returnIfFunction(e2);
  }
  isOpen() {
    return !!this.autocompleteItemsElement;
  }
  close() {
    this.closeDropDownList();
  }
  open() {
    this.isOpen() || this.openDropdownAgain();
  }
  sendGeocoderRequestOrAlt(e2) {
    return this.sendGeocoderRequestAlt ? this.sendGeocoderRequestAlt(e2, this) : this.sendGeocoderRequest(e2);
  }
  sendGeocoderRequest(e2) {
    return new Promise((o2, i2) => {
      this.currentPromiseReject = i2;
      let a2 = n.generateUrl(e2, this.geocoderUrl, this.apiKey, this.options);
      fetch(a2).then((e3) => {
        e3.ok ? e3.json().then((e4) => o2(e4)) : e3.json().then((e4) => i2(e4));
      });
    });
  }
  sendPlaceDetailsRequest(e2) {
    return new Promise((o2, i2) => {
      if (n.isNotOpenStreetMapData(e2)) return void o2(e2);
      this.currentPlaceDetailsPromiseReject = i2;
      let a2 = n.generatePlacesUrl(this.placeDetailsUrl, e2.properties.place_id, this.apiKey, this.options);
      fetch(a2).then((a3) => {
        a3.ok ? a3.json().then((i3) => {
          i3.features.length || o2(e2), o2(i3.features[0]);
        }) : a3.json().then((e3) => i2(e3));
      });
    });
  }
  onUserInput(e2) {
    let o2 = this.inputElement.value, i2 = this.inputElement.value;
    if (this.callbacks.notifyInputChange(o2), this.closeDropDownList(), this.focusedItemIndex = -1, this.cancelPreviousRequest(), this.cancelPreviousTimeout(), !o2) return this.removeClearButton(), false;
    this.showClearButton(), this.currentTimeout = window.setTimeout(() => {
      n.returnIfFunction(this.preprocessHook) && (o2 = this.preprocessHook(o2)), this.sendGeocoderRequestOrAlt(o2).then((o3) => {
        this.onDropdownDataLoad(o3, i2, e2);
      }, (e3) => {
        e3.canceled || console.log(e3);
      });
    }, this.options.debounceDelay);
  }
  onDropdownDataLoad(e2, o2, i2) {
    n.needToCalculateExtendByNonVerifiedValues(e2, this.options) && n.extendByNonVerifiedValues(this.options, e2.features, e2?.query?.parsed), this.currentItems = e2.features, n.needToFilterDataBySuggestionsFilter(this.currentItems, this.suggestionsFilter) && (this.currentItems = this.suggestionsFilter(this.currentItems)), this.callbacks.notifySuggestions(this.currentItems), this.currentItems.length && (this.createDropdown(), this.currentItems.forEach((e3, a2) => {
      this.populateDropdownItem(e3, o2, i2, a2);
    }));
  }
  populateDropdownItem(e2, o2, i2, a2) {
    const t2 = l.createDropdownItem();
    this.options.skipIcons || l.addDropdownIcon(e2, t2);
    const d2 = l.createDropdownItemText();
    if (n.returnIfFunction(this.postprocessHook)) {
      const i3 = this.postprocessHook(e2);
      d2.innerHTML = l.getStyledAddressSingleValue(i3, o2);
    } else d2.innerHTML = l.getStyledAddress(e2.properties, o2);
    t2.appendChild(d2), this.addEventListenerOnDropdownClick(t2, i2, a2), this.autocompleteItemsElement.appendChild(t2);
  }
  addEventListenerOnDropdownClick(e2, o2, i2) {
    e2.addEventListener("click", (e3) => {
      o2.stopPropagation(), this.setValueAndNotify(this.currentItems[i2]);
    });
  }
  createDropdown() {
    this.autocompleteItemsElement = document.createElement("div"), this.autocompleteItemsElement.setAttribute("class", "geoapify-autocomplete-items"), this.callbacks.notifyOpened(), this.container.appendChild(this.autocompleteItemsElement);
  }
  cancelPreviousTimeout() {
    this.currentTimeout && (window.clearTimeout(this.currentTimeout), this.currentTimeout = null);
  }
  cancelPreviousRequest() {
    this.currentPromiseReject && (this.currentPromiseReject({
      canceled: true
    }), this.currentPromiseReject = null);
  }
  addEventListeners() {
    this.inputElement.addEventListener("input", this.onUserInput.bind(this), false), this.inputElement.addEventListener("keydown", this.onUserKeyPress.bind(this), false), document.addEventListener("click", (e2) => {
      e2.target !== this.inputElement ? this.closeDropDownList() : this.autocompleteItemsElement || this.openDropdownAgain();
    });
  }
  showClearButton() {
    this.inputClearButton.classList.add("visible");
  }
  removeClearButton() {
    this.inputClearButton.classList.remove("visible");
  }
  onUserKeyPress(e2) {
    if (this.autocompleteItemsElement) {
      const o2 = this.autocompleteItemsElement.getElementsByTagName("div");
      "ArrowDown" === e2.code ? this.handleArrowDownEvent(e2, o2) : "ArrowUp" === e2.code ? this.handleArrowUpEvent(e2, o2) : "Enter" === e2.code ? this.handleEnterEvent(e2) : "Escape" === e2.code && this.closeDropDownList();
    } else "ArrowDown" == e2.code && this.openDropdownAgain();
  }
  handleEnterEvent(e2) {
    e2.preventDefault(), this.focusedItemIndex > -1 && (this.options.skipSelectionOnArrowKey ? this.setValueAndNotify(this.currentItems[this.focusedItemIndex]) : this.closeDropDownList());
  }
  handleArrowUpEvent(e2, o2) {
    e2.preventDefault(), this.focusedItemIndex--, this.focusedItemIndex < 0 && (this.focusedItemIndex = o2.length - 1), this.setActive(o2, this.focusedItemIndex);
  }
  handleArrowDownEvent(e2, o2) {
    e2.preventDefault(), this.focusedItemIndex++, this.focusedItemIndex >= o2.length && (this.focusedItemIndex = 0), this.setActive(o2, this.focusedItemIndex);
  }
  setActive(e2, o2) {
    if (!e2 || !e2.length) return false;
    l.addActiveClassToDropdownItem(e2, o2), this.options.skipSelectionOnArrowKey || (this.inputElement.value = n.returnIfFunction(this.postprocessHook) ? this.postprocessHook(this.currentItems[o2]) : this.currentItems[o2].properties.formatted, this.notifyValueSelected(this.currentItems[o2]));
  }
  setValueAndNotify(e2) {
    this.inputElement.value = n.returnIfFunction(this.postprocessHook) ? this.postprocessHook(e2) : e2.properties.formatted, this.notifyValueSelected(e2), this.closeDropDownList();
  }
  clearFieldAndNotify(e2) {
    e2.stopPropagation(), this.inputElement.value = "", this.removeClearButton(), this.cancelPreviousRequest(), this.cancelPreviousTimeout(), this.closeDropDownList(), this.notifyValueSelected(null);
  }
  closeDropDownList() {
    this.autocompleteItemsElement && (this.container.removeChild(this.autocompleteItemsElement), this.autocompleteItemsElement = null, this.callbacks.notifyClosed());
  }
  notifyValueSelected(e2) {
    this.cancelPreviousPlaceDetailsRequest(), this.noNeedToRequestPlaceDetails(e2) ? this.callbacks.notifyChange(e2) : this.sendPlaceDetailsRequestOrAlt(e2).then((e3) => {
      this.callbacks.notifyChange(e3), this.currentPlaceDetailsPromiseReject = null;
    }, (o2) => {
      o2.canceled || (console.log(o2), this.callbacks.notifyChange(e2), this.currentPlaceDetailsPromiseReject = null);
    });
  }
  sendPlaceDetailsRequestOrAlt(e2) {
    return this.sendPlaceDetailsRequestAlt ? this.sendPlaceDetailsRequestAlt(e2, this) : this.sendPlaceDetailsRequest(e2);
  }
  noNeedToRequestPlaceDetails(e2) {
    return !this.options.addDetails || !e2 || e2.properties.nonVerifiedParts?.length;
  }
  cancelPreviousPlaceDetailsRequest() {
    this.currentPlaceDetailsPromiseReject && (this.currentPlaceDetailsPromiseReject({
      canceled: true
    }), this.currentPlaceDetailsPromiseReject = null);
  }
  openDropdownAgain() {
    const e2 = document.createEvent("Event");
    e2.initEvent("input", true, true), this.inputElement.dispatchEvent(e2);
  }
  constructOptions(e2) {
    this.options = e2 ? __spreadValues(__spreadValues({}, this.options), e2) : this.options, this.options.filter = this.options.filter || {}, this.options.bias = this.options.bias || {}, this.options.countryCodes && this.addFilterByCountry(this.options.countryCodes), this.options.position && this.addBiasByProximity(this.options.position);
  }
  addClearButton() {
    this.inputClearButton = document.createElement("div"), this.inputClearButton.classList.add("geoapify-close-button"), l.addIcon(this.inputClearButton, "close"), this.inputClearButton.addEventListener("click", this.clearFieldAndNotify.bind(this), false), this.container.appendChild(this.inputClearButton);
  }
};
export {
  s as GeocoderAutocomplete
};
//# sourceMappingURL=@geoapify_geocoder-autocomplete.js.map
