
package com.dietiEstates.backend.service;

import org.springframework.stereotype.Service;


@Service
public class RealEstateAgentService 
{
    //TODO methods:

    //createRealEstate    
}
