
package com.dietiEstates.backend.service;

import org.springframework.stereotype.Service;

import java.util.regex.Pattern;


@Service
public class ValidatorService 
{
    private static final Pattern emailPattern = Pattern.compile("[a-z,0-9]+@[a-z]+\\.[a-z]+");
    private static final Pattern passwordPattern1 = Pattern.compile("[A-Z]+");
    private static final Pattern passwordPattern2 = Pattern.compile("\\d+");
    private static final Pattern passwordPattern3 = Pattern.compile("[!-/,:-@,91-96,{-}]+");


    boolean emailValidator(String email)
    {
        return email == null ? false : emailPattern.matcher(email).matches();
    }


    boolean passwordValidator(String password)
    {
        return password == null ? false : passwordPattern1.matcher(password).find() &&
                                          passwordPattern2.matcher(password).find() &&
                                          passwordPattern3.matcher(password).find();
    }

    
    //TODO methods:
    //usernamevalidator  
}
