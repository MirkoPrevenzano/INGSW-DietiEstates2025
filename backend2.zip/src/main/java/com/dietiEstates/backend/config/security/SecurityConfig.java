
package com.dietiEstates.backend.config.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.dietiEstates.backend.config.security.filter.JWTAuthenticationFilter;
import com.dietiEstates.backend.config.security.filter.JWTAuthorizationFilter;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;


@Configuration
@EnableWebSecurity
@EnableMethodSecurity
@RequiredArgsConstructor
@Slf4j
public class SecurityConfig 
{
	@Bean 
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration) throws Exception
    {
        return authenticationConfiguration.getAuthenticationManager();
    }

    @Bean
    @Order(1)
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception
    {
        JWTAuthenticationFilter jwtAuthenticationFilter = new JWTAuthenticationFilter( 
                                                                authenticationManager(http.getSharedObject(AuthenticationConfiguration.class)));          
        jwtAuthenticationFilter.setFilterProcessesUrl("/login/**");

        http.csrf(a -> a.disable())
            .securityMatcher("/login/**","/auth/**")
            .sessionManagement(a -> a.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
			.authorizeHttpRequests(a-> a.requestMatchers("/login/**").permitAll())
            //.authorizeHttpRequests(a -> a.requestMatchers("/auth/path/**").hasAuthority("ROLE_USER"))
			.addFilter(jwtAuthenticationFilter)
            .addFilterBefore(new JWTAuthorizationFilter(), UsernamePasswordAuthenticationFilter.class)
            .authorizeHttpRequests(a-> a.anyRequest().authenticated())
            .httpBasic(Customizer.withDefaults());

        return http.build();
    }

    
    @Bean
    @Order(2)
    public SecurityFilterChain securityFilterChain2(HttpSecurity http) throws Exception
    {            
        JWTAuthenticationFilter jwtAuthenticationFilter = new JWTAuthenticationFilter( 
                                                               authenticationManager(http.getSharedObject(AuthenticationConfiguration.class)));     
        jwtAuthenticationFilter.setFilterProcessesUrl("/login/google/**");

        http.csrf(a -> a.disable())
            .sessionManagement(a -> a.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
			.authorizeHttpRequests(a-> a.requestMatchers("/login/google/**").permitAll())
            //.authorizeHttpRequests(a -> a.requestMatchers("/auth/path/**").hasAuthority("ROLE_AGENT"))
			.addFilter(jwtAuthenticationFilter)
            .addFilterBefore(new JWTAuthorizationFilter(), UsernamePasswordAuthenticationFilter.class)
            .authorizeHttpRequests(a-> a.anyRequest().authenticated())
            .httpBasic(Customizer.withDefaults());

        return http.build();
    }
}

