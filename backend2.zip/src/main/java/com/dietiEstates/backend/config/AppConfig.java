package com.dietiEstates.backend.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.dietiEstates.backend.model.Administrator;
import com.dietiEstates.backend.model.Customer;
import com.dietiEstates.backend.model.RealEstateAgent;
import com.dietiEstates.backend.model.repository.AdministratorRepository;
import com.dietiEstates.backend.model.repository.CustomerRepository;
import com.dietiEstates.backend.model.repository.RealEstateAgentRepository;

import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;

import java.util.Optional;

import org.modelmapper.ModelMapper;


@Configuration
@RequiredArgsConstructor
@Slf4j
public class AppConfig 
{
    private final CustomerRepository customerRepository;
    private final RealEstateAgentRepository realEstateAgentRepository;
    private final AdministratorRepository administratorRepository;
    
    @Autowired
    private HttpServletRequest httpServletRequest;

    
    @Bean
    public ModelMapper modelMapper() 
    {
        return new ModelMapper();
    }

    @Bean 
	public PasswordEncoder passwordEncoder()
	{
		return new BCryptPasswordEncoder();
	}

    @Bean
    public UserDetailsService userDetailsService()
    {
       return new UserDetailsService() 
       {
            @Override
            public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException 
            {
                switch(httpServletRequest.getParameter("role"))
                {
                    case "customer" :
                    {
                        Optional<Customer> customer = customerRepository.findByUsername(username);
                        if(customer.isEmpty())
                        {
                            log.error("Customer not found in database");
                            throw new UsernameNotFoundException("Customer not found in database");
                        }
                        else
                        {
                            log.info("Customer found in database: {}", username);
                            return customer.get();
                        }
                    }

                    case "agent" :
                    {
                        Optional<RealEstateAgent> realEstateAgent = realEstateAgentRepository.findByUsername(username);
                        if(realEstateAgent.isEmpty())
                        {
                            log.error("Real Estate Agent not found in database");
                            throw new UsernameNotFoundException("Real Estate Agent not found in database");
                        }
                        else
                        {
                            log.info("Real Estate Agent found in database: {}", username);
                            return realEstateAgent.get();
                        }                        
                    }

                    case "admin" :
                    {
                        Optional<Administrator> administrator = administratorRepository.findByUsername(username);
                        if(administrator.isEmpty())
                        {
                            log.error("Administrator not found in database");
                            throw new UsernameNotFoundException("Administrator not found in database");
                        }
                        else
                        {
                            log.info("Administrator found in database: {}", username);
                            return administrator.get();
                        }                           
                    }

                    default : 
                    {
                        log.error("Wrong role inserted!");
                        throw new IllegalArgumentException("Wrong role inserted!");
                    }
                }          
            }
        };
    }

    @Bean
    public AuthenticationManager buildAuthenticationManager(HttpSecurity http) throws Exception 
    {
        AuthenticationManagerBuilder authenticationManagerBuilder = http.getSharedObject(AuthenticationManagerBuilder.class);
        
        authenticationManagerBuilder.userDetailsService(userDetailsService())
                                    .passwordEncoder(passwordEncoder());

        return authenticationManagerBuilder.build();
    }
}
