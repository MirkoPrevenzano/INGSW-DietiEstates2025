
package com.dietiEstates.backend.model;


public enum Role 
{
    ROLE_USER,
    ROLE_AGENT,
    ROLE_ADMIN
}
