
package com.dietiEstates.backend.model;

import org.springframework.security.core.userdetails.UserDetails;

import jakarta.persistence.Column;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;
import lombok.NonNull;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;


@MappedSuperclass
@Data
@NoArgsConstructor
@RequiredArgsConstructor
public abstract class User implements UserDetails
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userId;

    @NonNull
    @Column(nullable = false, 
            updatable = true,
            length = 25)
    private String name;

    @NonNull
    @Column(nullable = false, 
            updatable = true,
            length = 25)
    private String surname;

    @NonNull
    @Column(nullable = false, 
            updatable = true,
            length = 25)
    private String username;

    @NonNull
    @Column(nullable = false, 
            updatable = true,
            length = 255)
    private String password; 

    @Enumerated(EnumType.STRING)
    Role role;
}
